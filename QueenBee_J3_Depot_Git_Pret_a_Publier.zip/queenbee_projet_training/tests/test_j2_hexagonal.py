"""J2 A3: boundaries, abuse tests and no side effects on failed validation."""

from __future__ import annotations

import json
import sqlite3
from uuid import uuid4

import pytest

from queenbee.adapters.inbound.agent_api import UnauthenticatedError, parse_agent_message, sign
from queenbee.adapters.inbound.log_parser import parse_sshd_line
from queenbee.adapters.outbound.repositories import InMemoryIncidentRepository, SqliteIncidentRepository
from queenbee.application.services import AccessDeniedError, IncidentService
from queenbee.domain.model import Alert, DomainError, Incident, IncidentStatus, Principal, Severity

KEY = bytes(range(32))


def _msg(**extra: str) -> bytes:
    payload = {
        "source_ip": "10.0.0.66",
        "username": "root",
        "action": "login_failed",
        "timestamp": "2026-10-15T09:00:00+02:00",
    } | extra
    return json.dumps(payload).encode()


class SpyRepository(InMemoryIncidentRepository):
    def __init__(self) -> None:
        super().__init__()
        self.lookups = 0
        self.saves = 0

    def get(self, incident_id):  # type: ignore[no-untyped-def]
        self.lookups += 1
        return super().get(incident_id)

    def save(self, incident: Incident) -> None:
        self.saves += 1
        super().save(incident)


def test_abuse_forged_hmac_rejected() -> None:
    data = _msg()
    with pytest.raises(UnauthenticatedError):
        parse_agent_message(data, sign(data, b"z" * 32), KEY)


def test_abuse_added_is_admin_field_rejected() -> None:
    data = _msg(is_admin="true")
    with pytest.raises(DomainError):
        parse_agent_message(data, sign(data, KEY), KEY)


def test_abuse_oversized_message_rejected_before_parse() -> None:
    data = b"{" + b"a" * 5000
    with pytest.raises(DomainError, match="4 KiB"):
        parse_agent_message(data, b"bad", KEY)


def test_abuse_null_byte_log_rejected() -> None:
    with pytest.raises(DomainError):
        parse_sshd_line("\x00" * 500)


def test_abuse_viewer_rejected_before_repository_lookup() -> None:
    repo = SpyRepository()
    viewer = Principal("viewer", frozenset({"viewer"}))
    with pytest.raises(AccessDeniedError):
        IncidentService(repo).move(viewer, uuid4(), IncidentStatus.TRIAGED)
    assert repo.lookups == 0
    assert repo.saves == 0


def test_abuse_direct_close_rejected_without_save() -> None:
    repo = SpyRepository()
    inc = Incident(Alert("brute_force", "10.0.0.66", Severity.HIGH, "5 failures"))
    repo.save(inc)
    saved = repo.saves
    analyst = Principal("alice", frozenset({"analyst"}))
    with pytest.raises(DomainError):
        IncidentService(repo).move(analyst, inc.id, IncidentStatus.CLOSED)
    assert inc.status == IncidentStatus.OPEN
    assert repo.saves == saved


def test_abuse_sqlite_payload_remains_data() -> None:
    db = sqlite3.connect(":memory:")
    repository = SqliteIncidentRepository(db)
    # A payload is hostile SQL syntax but the repository treats it as a value.
    incident = Incident(Alert("r", "10.0.0.66", Severity.HIGH, "a'); DROP TABLE incidents;--"))
    repository.save(incident)
    assert repository.get(incident.id) is not None
    assert db.execute("SELECT count(*) FROM incidents").fetchone() == (1,)


def test_analyst_can_move_incident_and_get_result() -> None:
    repo = SpyRepository()
    incident = Incident(Alert("r", "10.0.0.66", Severity.HIGH, "x"))
    repo.save(incident)
    analyst = Principal("alice", frozenset({"analyst"}))
    result = IncidentService(repo).move(analyst, incident.id, IncidentStatus.TRIAGED)
    assert result.status is IncidentStatus.TRIAGED
    assert repo.get(incident.id) is result
