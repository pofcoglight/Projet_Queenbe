"""J2 A1: five defensive patterns demonstrated through attack-style tests."""

from __future__ import annotations

import pytest

from queenbee.adapters.inbound.log_parser import parse_sshd_line
from queenbee.adapters.outbound.notifiers import (
    AuditedNotifier,
    MemoryNotifier,
    ObserverNotifier,
    RateLimitedNotifier,
)
from queenbee.adapters.outbound.repositories import InMemoryIncidentRepository
from queenbee.adapters.outbound.response import BlockIpCommand, InMemoryFirewall
from queenbee.application.access import IncidentReadProxy
from queenbee.application.services import AccessDeniedError
from queenbee.domain.model import Alert, DomainError, Incident, IncidentStatus, Principal, Severity


class SpyRepository(InMemoryIncidentRepository):
    def __init__(self) -> None:
        super().__init__()
        self.read_count = 0

    def list_open(self) -> list[Incident]:
        self.read_count += 1
        return super().list_open()


class BrokenSubscriber:
    def notify(self, alert: Alert) -> None:
        raise RuntimeError("simulated failed integration")


def _alert() -> Alert:
    return Alert("brute_force", "10.0.0.66", Severity.HIGH, "failed SSH logins")


def test_abuse_proxy_refuses_unauthorized_reader_without_repository_access() -> None:
    repository = SpyRepository()
    user = Principal("mallory", frozenset())
    with pytest.raises(AccessDeniedError):
        IncidentReadProxy(repository, user).list_open()
    assert repository.read_count == 0  # refusal before any data access


def test_abuse_decorator_absorbs_flood_and_counts_rejections() -> None:
    now = [0.0]
    sink = MemoryNotifier()
    limited = RateLimitedNotifier(sink, 3, 60, clock=lambda: now[0])
    for _ in range(1000):
        limited.notify(_alert())
    assert (len(sink.received), limited.dropped) == (3, 997)
    now[0] = 61.0
    limited.notify(_alert())
    assert (len(sink.received), limited.dropped) == (4, 997)


def test_abuse_adapter_rejects_injection_and_null_bytes() -> None:
    good = "2026-10-15T09:00:00+02:00 sshd: Failed password for root from 10.0.0.66"
    for candidate in (good + " OR 1=1", good.replace("root", "root;rm"), good + "\x00", "x"*10000):
        with pytest.raises(DomainError):
            parse_sshd_line(candidate)


def test_abuse_observer_continues_when_one_subscriber_breaks() -> None:
    observers = ObserverNotifier()
    good = MemoryNotifier()
    observers.subscribe(BrokenSubscriber())
    observers.subscribe(good)
    observers.notify(_alert())
    assert observers.failures == 1
    assert len(good.received) == 1


def test_abuse_state_rejects_direct_close_without_mutation() -> None:
    incident = Incident(_alert())
    with pytest.raises(DomainError):
        incident.transition_to(IncidentStatus.CLOSED)
    assert incident.status == IncidentStatus.OPEN


def test_abuse_command_refuses_shell_input_without_firewall_effect() -> None:
    firewall = InMemoryFirewall()
    with pytest.raises(ValueError):
        BlockIpCommand(firewall, "1.2.3.4; iptables -F")
    assert not firewall.blocked


def test_decorator_audit_keeps_original_behavior(caplog: pytest.LogCaptureFixture) -> None:
    sink = MemoryNotifier()
    with caplog.at_level("INFO", logger="queenbee.audit"):
        AuditedNotifier(sink).notify(_alert())
    assert len(sink.received) == 1
    assert "brute_force" in caplog.text
