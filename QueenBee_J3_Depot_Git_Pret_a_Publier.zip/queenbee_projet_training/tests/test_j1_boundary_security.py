"""J1: extra negative tests for the threat model's security boundaries."""

from __future__ import annotations

import json

import pytest

from queenbee.adapters.inbound.agent_api import (
    UnauthenticatedError,
    parse_agent_message,
    sign,
)
from queenbee.adapters.inbound.log_parser import parse_sshd_line
from queenbee.adapters.inbound.threat_feed import ThreatFeedTranslator
from queenbee.bootstrap import build_app
from queenbee.config import ConfigError, SettingsBuilder, copy_settings, settings_from_env
from queenbee.domain.model import DomainError
from queenbee.factories import ProdFactory

KEY = bytes(range(32))
GOOD = "2026-10-14T09:00:00+02:00 sshd: Failed password for root from 10.0.0.66"


def _message(**over: str) -> bytes:
    data = {
        "source_ip": "10.0.0.66", "username": "root", "action": "login_failed",
        "timestamp": "2026-10-14T09:00:00+00:00",
    } | over
    return json.dumps(data).encode()


def test_signed_events_validated_and_forged_signatures_denied() -> None:
    data = _message()
    event = parse_agent_message(data, sign(data, KEY), KEY)
    assert event.source_ip == "10.0.0.66"
    with pytest.raises(UnauthenticatedError):
        parse_agent_message(data, sign(data, bytes(32)), KEY)


def test_forged_fields_or_invalid_payload_denied() -> None:
    for data in (
        _message(is_admin="true"),
        _message(source_ip="999.999.1.1"),
        _message(timestamp="not_a_date"),
        b"[]",
        b"{}",
        b"not json",
        b"{" + b" " * 4096 + b"}",
    ):
        with pytest.raises(DomainError):
            parse_agent_message(data, sign(data, KEY), KEY)


def test_invalid_log_inputs_denied() -> None:
    assert parse_sshd_line(GOOD).username == "root"
    for line in (
        GOOD + "junk", GOOD.replace("root", "<script>"),
        GOOD.replace("10.0.0.66", "bad_ip"),
        "", "a" * 600, GOOD.replace("2026-10-14", "2026-99-99"),
    ):
        with pytest.raises(DomainError):
            parse_sshd_line(line)


def test_full_training_path_drops_invalid_lines() -> None:
    app = build_app(settings_from_env({"QUEENBEE_AGENT_KEY": KEY.hex()}))
    created = app.ingest_lines([GOOD] * 5 + ["garbage"])
    assert len(created) == 1
    assert app.rejected == 1


def test_feed_translator_validates_its_input() -> None:
    tr = ThreatFeedTranslator()
    assert tr.translate({"indicator": "203.0.113.9", "risk_level": "high"}).score == 80
    for data in (
        {"indicator": "evil.test", "risk_level": "high"},
        {"indicator": "10.0.0.1", "risk_level": "bogus"},
        {"indicator": "10.0.0.1"},
    ):
        with pytest.raises(DomainError):
            tr.translate(data)


def test_config_loader_and_prototype_security() -> None:
    with pytest.raises(ConfigError):
        settings_from_env({})
    with pytest.raises(ConfigError):
        settings_from_env({"QUEENBEE_AGENT_KEY": "garbage"})
    with pytest.raises(ConfigError):
        settings_from_env({"QUEENBEE_AGENT_KEY": "00"})
    cfg = SettingsBuilder().hmac_key(KEY).database_path(":memory:").max_notifications(5).build()
    assert KEY.hex() not in repr(cfg)
    strict = copy_settings(cfg, max_notifications=2)
    assert strict.max_notifications == 2
    with pytest.raises(ConfigError):
        copy_settings(cfg, agent_hmac_key=b"bad")
    with pytest.raises(ConfigError):
        SettingsBuilder().hmac_key(KEY).database_path("").build()
    with pytest.raises(ConfigError):
        SettingsBuilder().build()
    with pytest.raises(ConfigError):
        SettingsBuilder().hmac_key(KEY).max_notifications(0).build()


def test_factory_keeps_a_safe_in_memory_notifier() -> None:
    factory = ProdFactory(":memory:")
    assert factory.notifier().received == []
