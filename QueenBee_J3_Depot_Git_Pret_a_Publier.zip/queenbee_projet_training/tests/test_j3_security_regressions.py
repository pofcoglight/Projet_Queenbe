"""J3 A1 — seven security regression tests on the corrected implementation.

The deliberately vulnerable LAB lives elsewhere; no external system is called.
"""

from __future__ import annotations

import inspect
import json
import sqlite3
from datetime import UTC, datetime
from uuid import uuid4

import pytest

from queenbee.adapters.inbound.agent_api import UnauthenticatedError, parse_agent_message, sign
from queenbee.adapters.inbound.log_parser import parse_sshd_line
from queenbee.adapters.inbound.service_auth import (
    AuthenticatedEnrichmentService,
    ServiceAuthenticationError,
    encode_enrichment_request,
)
from queenbee.adapters.outbound.repositories import InMemoryIncidentRepository, SqliteIncidentRepository
from queenbee.application.services import AccessDeniedError, IncidentService
from queenbee.config import ConfigError, Settings, settings_from_env
from queenbee.domain.model import Alert, DomainError, Incident, IncidentStatus, Principal, Severity

KEY = bytes(range(32))
KEY_2 = bytes(range(1, 33))


def _alert() -> Alert:
    return Alert("brute_force", "10.0.0.66", Severity.HIGH, "5 failed attempts")


def test_j3_fix_01_secret_not_committed_and_injected_at_runtime() -> None:
    with pytest.raises(ConfigError):
        settings_from_env({})
    config = settings_from_env({"QUEENBEE_AGENT_KEY": KEY.hex()})
    assert config.agent_hmac_key == KEY
    assert KEY.hex() not in repr(config)
    # No default value, no secret literal; static gitleaks scan still required separately.
    assert "secret" not in repr(Settings(KEY)).lower()


def test_j3_fix_02_bounded_parser_rejects_redos_input() -> None:
    for text in ("a" * 18 + "!", "a" * 22 + "!", "a" * 10_000 + "!"):
        with pytest.raises(DomainError):
            parse_sshd_line(text)
    # Test checks bound + rejection rather than fragile timing assertions.


def test_j3_fix_03_signed_json_rejects_untrusted_pickle() -> None:
    # A pickle payload must not be parsed, let alone executed.
    raw = b"\x80\x04\x95\x00\x00\x00\x00\x00\x00\x00\x00."
    with pytest.raises((DomainError, UnauthenticatedError)):
        parse_agent_message(raw, sign(raw, KEY), KEY)
    valid = json.dumps({
        "source_ip": "10.0.0.66", "username": "root", "action": "login_failed",
        "timestamp": datetime.now(UTC).isoformat(),
    }).encode()
    assert parse_agent_message(valid, sign(valid, KEY), KEY).source_ip == "10.0.0.66"


def test_j3_fix_04_parameterized_sql_keeps_payload_as_data() -> None:
    conn = sqlite3.connect(":memory:")
    repo = SqliteIncidentRepository(conn)
    inc = Incident(Alert("test", "10.0.0.66", Severity.HIGH, "x' OR '1'='1"))
    repo.save(inc)
    assert repo.get(inc.id) is not None
    assert repo.get(uuid4()) is None
    assert conn.execute("SELECT count(*) FROM incidents").fetchone() == (1,)


def test_j3_fix_05_authorization_denies_viewer_without_effect() -> None:
    repository = InMemoryIncidentRepository()
    inc = Incident(_alert())
    repository.save(inc)
    with pytest.raises(AccessDeniedError):
        IncidentService(repository).move(
            Principal("mallory", frozenset({"viewer"})), inc.id, IncidentStatus.TRIAGED,
        )
    assert repository.get(inc.id) is inc
    assert inc.status is IncidentStatus.OPEN


def test_j3_fix_06_interservice_auth_before_processing() -> None:
    gateway = AuthenticatedEnrichmentService({"ingestion": KEY, "detector": KEY_2}, clock=lambda: 100)
    body, token = encode_enrichment_request("ingestion", "10.0.0.66", 95, KEY)
    assert gateway.enrich(body, token)["reputation"] == "unknown"
    assert gateway.calls == 1
    for forged in (b"", b"x" * 32, encode_enrichment_request("ingestion", "10.0.0.66", 95, KEY_2)[1]):
        with pytest.raises(ServiceAuthenticationError):
            gateway.enrich(body, forged)
    assert gateway.calls == 1
    old, old_sig = encode_enrichment_request("ingestion", "10.0.0.66", 50, KEY)
    with pytest.raises(ServiceAuthenticationError):
        gateway.enrich(old, old_sig)
    assert gateway.calls == 1
    with pytest.raises(ValueError, match="share"):
        AuthenticatedEnrichmentService({"ingestion": KEY, "detector": KEY})


def test_j3_fix_07_hmac_verification_uses_compare_digest() -> None:
    source = inspect.getsource(parse_agent_message)
    assert "hmac.compare_digest" in source
    data = b"{}"
    with pytest.raises(UnauthenticatedError):
        parse_agent_message(data, sign(data, KEY_2), KEY)
