"""Four extra harmless, local proofs for J3, completing 7 lab demonstrations.

IMPORTANT: these checks intentionally describe insecure behavior in labs/ only.
"""

from __future__ import annotations

import inspect

import pytest

from labs import vulnerable_queenbee as vulnerable

pytestmark = pytest.mark.lab


def test_faille1_secret_in_source_and_shared() -> None:
    source = inspect.getsource(vulnerable)
    assert 'API_KEY = "qb-admin-2026"' in source
    assert "API_KEY" in inspect.getsource(vulnerable.check_token)


def test_faille5_viewer_can_close_incident() -> None:
    cursor = vulnerable.conn.execute(
        "INSERT INTO incident (ip,status) VALUES (?,?)", ("10.0.0.88", "open")
    )
    vuln_id = cursor.lastrowid
    assert vuln_id is not None
    vulnerable.close_incident("viewer", vuln_id)
    assert vulnerable.conn.execute(
        "SELECT status FROM incident WHERE id=?", (vuln_id,)
    ).fetchone() == ("closed",)


def test_faille6_enrichment_without_service_identity() -> None:
    # No authentication or identity is provided, yet the simulated call succeeds.
    assert vulnerable.call_enrichment_service("10.0.0.66")["ip"] == "10.0.0.66"


def test_faille7_plain_equality_used_for_token() -> None:
    # Source proof only: timing inference is too noisy to claim an exploit.
    body = inspect.getsource(vulnerable.check_token)
    assert "token == API_KEY" in body
