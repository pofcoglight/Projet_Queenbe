"""Two student-authored abuse tests plus security regressions for J1."""

from dataclasses import FrozenInstanceError, replace

import pytest

from queenbee.config import ConfigError, SettingsBuilder
from queenbee.domain.model import DomainError
from queenbee.domain.rules import build_rule


def test_j1_abuse_unknown_rule_is_never_executed() -> None:
    """A rule name is data, never executable Python or a module path."""
    with pytest.raises(DomainError):
        build_rule({"kind": "os.system", "threshold": 5})


def test_j1_abuse_boolean_threshold_port_scan_rejected() -> None:
    """True is a subclass of int but is not a permitted rule threshold."""
    with pytest.raises(DomainError):
        build_rule({"kind": "port_scan", "threshold": True})


def test_j1_builder_refuses_short_key() -> None:
    with pytest.raises(ConfigError):
        SettingsBuilder().hmac_key(b"short").build()


def test_j1_builder_immutable_and_key_redacted() -> None:
    key = bytes(range(32))
    settings = SettingsBuilder().hmac_key(key).build()
    assert key.hex() not in repr(settings)
    with pytest.raises(FrozenInstanceError):
        settings.max_notifications = 99  # type: ignore[misc]
    with pytest.raises(ConfigError):
        replace(settings, max_notifications=True)
