"""J1: observe legacy behavior without talking to a real mail server."""

from __future__ import annotations

import sqlite3
from pathlib import Path

import pytest

from legacy import log_watcher


@pytest.fixture
def legacy_spies(monkeypatch: pytest.MonkeyPatch) -> list[str]:
    connection = sqlite3.connect(":memory:")
    connection.execute("CREATE TABLE incidents (ip TEXT, username TEXT)")
    monkeypatch.setattr(log_watcher, "DB", connection)
    notified: list[str] = []
    monkeypatch.setattr(log_watcher.LogWatcher, "alert", lambda self, ip: notified.append(ip))
    return notified


def test_legacy_five_failures_trigger_one_alert(
    tmp_path: Path, legacy_spies: list[str]
) -> None:
    """Characterization only: the legacy fifth failure triggers exactly once."""
    log_path = tmp_path / "auth.log"
    log_path.write_text(
        "Failed password for root from 10.0.0.66\n" * 5, encoding="utf-8"
    )
    watcher = log_watcher.LogWatcher(str(log_path))
    watcher.run()
    assert watcher.counts["10.0.0.66"] == 5
    assert legacy_spies == ["10.0.0.66"]


def test_legacy_four_failures_do_not_alert(tmp_path: Path, legacy_spies: list[str]) -> None:
    """Characterization: threshold behavior is kept while refactoring."""
    log_path = tmp_path / "auth.log"
    log_path.write_text(
        "Failed password for root from 10.0.0.66\n" * 4, encoding="utf-8"
    )
    log_watcher.LogWatcher(str(log_path)).run()
    assert legacy_spies == []
