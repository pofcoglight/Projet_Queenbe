# Queen Bee — J3 : version GitHub (16 octobre 2026)

Ce **même dépôt** contient les trois journées, avec tags locaux : `j1-rendu`, `j2-rendu`, `j3-rendu`.

## Commencer ici

1. Ouvrir `docs/dossier_conception_securisee.md` : table des matières du dossier final.
2. Étudier `docs/recette_j3.md` : scénarios de recette, preuves et GO/NO-GO.
3. J3-A1 : variantes intentionnellement fragiles **seulement dans `labs/`**, testées localement.
4. J3-A2 : `docs/infrastructure_j3.md`, `docs/adr/0009-*` et `0010-*`.
5. J3-A3 : `docs/uml/`, `docs/release_j3.md` et trame orale.

## Windows PowerShell — prérequis Python 3.13 recommandé

```powershell
py -3.13 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -e ".[dev]"
.\.venv\Scripts\python.exe -m pytest -m lab -q
.\.venv\Scripts\python.exe -m pytest tests/test_j3_security_regressions.py -q
.\.venv\Scripts\python.exe -m pytest --cov=src/queenbee --cov-fail-under=90
$env:PYTHONPATH="src"; .\.venv\Scripts\lint-imports.exe
```

Pour les contrôles complets sur un système disposant de Make : `make check`. Sous PowerShell sans Make, voir `README_J2_RENDU.md` (Ruff, mypy, pytest-cov, Bandit, pip-audit, lint-imports). Pour les secrets, vérifier le dépôt et l'historique Git avec une solution de détection de secrets configurée pour le projet.

**La commande `-m lab` teste des failles volontairement présentes ; elle doit réussir pour une raison différente des tests de régression sur la version corrigée.** Ne jamais lancer ces démonstrations hors de `labs/` ou contre un système tiers.

## GitHub Desktop — travailler dans le dépôt existant

- Ne **PAS** créer un second dépôt si J1/J2 est déjà publié.
- Comparer le dernier commit de J2 à `j2-rendu` ; si l'historique distant est différent, intégrer les changements dans le dépôt existant plutôt que forcer un push.
- Si ce dépôt contient l'historique attendu, ouvrir dans GitHub Desktop (**File → Add Local Repository**), puis raccorder le dépôt distant existant en vérifiant les adresses dans **Repository → Repository Settings → Remote**.
- Vérifier l'absence de vrais secrets dans le code **et** l'historique avant publication.
- Après validation, publier les commits J3 et le tag :

```powershell
git status
git tag --list
git remote -v
git push origin HEAD
git push origin j3-rendu
```

**Ne pas réécrire les tags** `j1-rendu` et `j2-rendu`. Le dépôt contient des fichiers pédagogiques fragiles sous `labs/` ; il doit rester privé tant que la politique du formateur n'autorise pas leur diffusion.
