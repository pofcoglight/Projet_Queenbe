# Queen Bee — Jour 2 : guide de remise

Ce dépôt prolonge le **Jour 1 dans le même historique Git** ; tag J1 : `j1-rendu`.

## A1 — 5 patterns défensifs

- **Proxy** : `src/queenbee/application/access.py` — contrôle avant lecture.
- **Decorator** : `src/queenbee/adapters/outbound/notifiers.py` — audit et limitation.
- **Adapter** : `src/queenbee/adapters/inbound/log_parser.py` — parser borné.
- **Observer** : `src/queenbee/adapters/outbound/notifiers.py` — diffusion isolant les pannes.
- **State / Command** : `src/queenbee/domain/model.py` et
  `src/queenbee/adapters/outbound/response.py` — transitions et blocage IP annulable.
- Tests d'abus : `tests/test_j2_defensive.py`; UML : `docs/uml/j2_defensive_patterns.puml`.

## A2 — Parcours et ADR

- `docs/architecture_j2.md` (8 étapes, tranche verticale, comparaison d'architectures).
- `docs/adr/0001-architecture-hexagonale.md` (contexte, choix, alternatives, coûts, preuves).
- `docs/uml/c4_context.puml` (diagramme C4 niveau 1).
- `docs/threat_model.md` (menaces STRIDE actualisées).

## A3 — Architecture hexagonale

- `src/queenbee/domain/` : entités et règles sans technologie.
- `src/queenbee/application/` : cas d'usage, ports dont `Firewall`, autorisation.
- `src/queenbee/adapters/` : entrées (HMAC, JSON, logs) et sorties (SQLite, notifications, pare-feu mémoire).
- `src/queenbee/bootstrap.py` : assemblage.
- Contrat `layers` dans `pyproject.toml`.
- Tests de frontière : `tests/test_j2_hexagonal.py` ; Hypothesis : `tests/test_adapters.py`.

## Windows — installer et vérifier

Ouvrir le dossier `queenbee_projet_training` dans VS Code puis, dans PowerShell :

```powershell
py -3.13 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -e ".[dev]"
.\.venv\Scripts\python.exe -m pytest tests/test_services.py tests/test_adapters.py -q
.\.venv\Scripts\python.exe -m pytest tests/test_j2_defensive.py tests/test_j2_hexagonal.py -q
$env:PYTHONPATH="src"; .\.venv\Scripts\lint-imports.exe
.\.venv\Scripts\python.exe -m pytest --cov=src/queenbee --cov-fail-under=90
```

Sous Windows sans Make, voir `Guide_pratique_J2_15oct.docx` pour les six contrôles
à exécuter séparément. Vérifier `lint-imports` et `make check` (sur système avec Make)
**avant** remise, ils ne sont pas réputés verts du seul fait de l'archive.

## GitHub Desktop

Ouvrir ce dépôt via **File → Add local repository**, puis **Publish repository**
seulement si aucun dépôt distant du groupe n'existe. Sinon utiliser le dépôt partagé.
À la fin, vérifier le commit final et pousser le tag `j2-rendu` :

```powershell
git tag --list j1-rendu j2-rendu
git push origin HEAD
git push origin j2-rendu
```

Ne pas déplacer le tag `j1-rendu`. Vérifier `.env` absent de l'historique.
