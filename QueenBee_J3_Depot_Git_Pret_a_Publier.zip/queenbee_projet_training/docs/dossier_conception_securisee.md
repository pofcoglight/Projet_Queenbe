# Dossier de conception sécurisée — Queen Bee (J1 + J2 + J3)

**BC3 Architecture logicielle, fil rouge du 14 au 16 octobre 2026.**

## 1. Objet

Queen Bee ingère des événements Web/SSH/VPN, détecte notamment les échecs de connexion répétés, enregistre des incidents, notifie le SOC et permet leur triage sous contrôle d'accès.

## 2. Modéliser (J1)

- Actifs DICP, acteurs, DFD, frontières et 8 exigences : [`threat_model.md`](threat_model.md).
- Refactoring de `legacy/log_watcher.py` vers entités, règles et ports : [`refactoring_audit_J1.md`](refactoring_audit_J1.md).
- Factories et configuration contrôlée : `src/queenbee/config.py` et `factories.py`.

## 3. Structurer (J2)

- Patterns défensifs : Proxy, Decorator, Adapter, Observer, State/Command ; preuves [`test_j2_defensive.py`](../tests/test_j2_defensive.py).
- Architecture hexagonale : `domain` indépendant, `application` ports/services, `adapters` entrants/sortants, `bootstrap.py` comme racine de composition.
- Choix documentés : [`adr/0001-architecture-hexagonale.md`](adr/0001-architecture-hexagonale.md), [`architecture_j2.md`](architecture_j2.md).

## 4. Éprouver (J3-A1)

- Sept vulnérabilités intentionnelles : `labs/vulnerable_queenbee.py`, prouvées seulement en laboratoire local.
- Trois tests de labo fournis + quatre tests de labo ajoutés : `tests/test_lab_vulnerable.py`, `tests/test_j3_lab_extra_proofs.py`.
- Sept tests des versions corrigées : [`test_j3_security_regressions.py`](../tests/test_j3_security_regressions.py).
- Sept ADR spécifiques : dossier [`adr/j3/`](adr/j3/). Les protections 1–5 et 7 prolongent J1/J2 ; la simulation de l'authentification inter-services de la faille 6 est ajoutée en J3.

## 5. Concevoir l'infrastructure (J3-A2)

- Zones, F1–F7, refus par défaut, secrets, SIEM, RPO/RTO et protocole de reprise : [`infrastructure_j3.md`](infrastructure_j3.md).
- ADR infrastructure : [`0009`](adr/0009-infrastructure-segmentation.md) et [`0010`](adr/0010-secrets-journalisation-reprise.md).

## 6. Diagrammes (J3-A3)

- C4 contexte : [`c4_context.puml`](uml/c4_context.puml) ; C4 conteneurs avec frontières : [`c4_container.puml`](uml/c4_container.puml).
- UML classes [`classes_j3.puml`](uml/classes_j3.puml), composants [`architecture_composants_j3.puml`](uml/architecture_composants_j3.puml), séquence [`sequence_ingestion_j3.puml`](uml/sequence_ingestion_j3.puml).

## 7. Recette et livraison

- Traçabilité preuve d'exploitation ↔ correction ↔ test ↔ ADR : voir la table de `threat_model.md`.
- État de recette, tests et décision Go/No-Go : [`recette_j3.md`](recette_j3.md).
- Release, périmètre et dette : [`release_j3.md`](release_j3.md).

## 8. Synthèse de sécurité

Les contrôles de **code** réduisent les risques (HMAC, validation, objet immuable, autorisation, SQL paramétré, audit, limitation). Les contrôles d'**infrastructure cible** ajoutent segmentation, mTLS, coffre, SIEM et reprise. Ces éléments doivent être *réellement déployés et éprouvés* avant toute prétention de sécurité opérationnelle.

## 9. Trame orale de 5 minutes

- **0:00–0:30** : Queen Bee, actifs et menace principale (faux agent ou compromission des messages).
- **0:30–2:00** : choix de l'architecture hexagonale et ports/adaptateurs ; compromis reconnu.
- **2:00–3:30** : exemple de faille SQL ou pickle : preuve locale → correction → test inverse.
- **3:30–4:30** : zone DMZ, F1 HTTPS/HMAC, F3 base, refus par défaut ; RPO/RTO cibles.
- **4:30–5:00** : preuves exécutées et limites : outils restants, infrastructure non déployée.

Chaque membre du groupe présente un morceau, puis **2 minutes de questions**.
