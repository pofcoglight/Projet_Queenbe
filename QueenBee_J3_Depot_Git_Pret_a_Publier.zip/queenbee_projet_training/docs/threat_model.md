# Queen Bee — Modèle de menaces STRIDE (J1, 14 octobre 2026)

> Proposition de modélisation pour l'atelier A1, élaborée à partir des consignes, du gabarit `docs/threat_model.md` et des tests fournis. Ce document ne prouve pas que les tests passent : l'implémentation est à réaliser ensuite.

## 1. Périmètre et objectif

Queen Bee reçoit des événements des agents Web, SSH et VPN, les authentifie et les valide, applique les règles de détection, crée des incidents, notifie le SOC et peut commander des actions de réponse. Les flux externes sont présumés non fiables.

## 2. Actifs et propriétés DICP

| Actif | Pourquoi il compte | D | I | C | P |
|---|---|:---:|:---:|:---:|:---:|
| Événements d'agents | Entrées utilisées pour la détection | ✓ | ✓ |  |  |
| Incidents | Conservent les alertes et décisions de réponse | ✓ | ✓ | ✓ | ✓ |
| Clés HMAC des agents | Permettent d'authentifier les événements |  | ✓ | ✓ |  |
| Règles de détection | Déterminent les situations suspectes | ✓ | ✓ |  |  |
| Comptes et rôles SOC | Déterminent qui peut consulter et agir |  | ✓ | ✓ | ✓ |
| Journaux d'audit | Tracent les décisions et interventions | ✓ | ✓ |  | ✓ |

D : disponibilité ; I : intégrité ; C : confidentialité ; P : preuve.

## 3. Acteurs

- **Agent Web, SSH, VPN** : origine des événements.
- **Analyste SOC** : triage des incidents, suivi des alertes.
- **Administrateur** : configuration et maintenance des composants.
- **Attaquant externe** : falsification, saturation ou tentative d'accès non autorisé.
- **Agent compromis** : équipement doté de l'identité d'un agent légitime mais capable d'émettre des données trompeuses.

## 4. DFD — Diagramme de flux de données (niveau 1)

```text
ZONE A — HÔTES / RÉSEAU NON FIABLE
[Agents Web / SSH / VPN] 
         |
         | F1 : événements + signature HMAC
         v
========== TB1 : agents -> API d'ingestion ==========
[API d'ingestion : taille, signature et schéma]
         |
         | F2 : événements validés
         v
[Cœur Queen Bee : règles, détection, incidents]
         |             |                  |
         | F3          | F4               | F5
         v             v                  v
===== TB2 =====   ===== TB3 =====     ===== TB3 =====
[Base incidents] [Service notification] [Pare-feu externe]
                       |
                       v
                 [Analystes SOC]
                       |
                       | F6 : consultation, triage et clôture
                       v
             ==== TB4 : utilisateur -> console SOC ====
                  [Console SOC / contrôle d'accès]
                       |
                       v
               [Cœur Queen Bee]

[Cœur / notifications] -- F7 : traces d'audit --> [SIEM externe]
                              (TB3, sortie vers un tiers)
```

**Justification des frontières**

- **TB1** : les agents peuvent être attaqués ou compromis ; le corps du message ne peut pas être considéré comme authentique sans vérification.
- **TB2** : la base est une ressource sensible ; le cœur ne doit transmettre que des données validées et employer des opérations paramétrées.
- **TB3** : les notifications, le pare-feu et le SIEM sont des services externes au cœur métier ; chaque interaction nécessite un contrat et une gestion des droits ou des erreurs.
- **TB4** : un compte connecté à la console ne possède pas automatiquement le droit de modifier les incidents.

## 5. Matrice STRIDE sur les flux qui franchissent les frontières

| Frontière / flux | S — Usurpation | T — Altération | R — Répudiation | I — Divulgation | D — Déni de service | E — Élévation de privilèges |
|---|---|---|---|---|---|---|
| TB1 / F1 agents → ingestion | Faux agent | Message ou champs altérés | Agent nie l'envoi | Secret d'authentification divulgué | Flood d'événements, entrée pathologique | Champs inattendus visant à étendre les droits |
| TB2 / F3 cœur → base | Identité de service usurpée | Incident modifié, injection SQL | Modification non tracée | Accès abusif aux incidents | Base saturée | Écriture hors périmètre |
| TB3 / F4-F5-F7 services externes | Fausse destination | Notification ou commande altérée | Blocage contesté sans audit | Secret ou contenu sensible dans les logs | Notifications excessives | Commande pare-feu non autorisée |
| TB4 / F6 analyste → console | Compte SOC usurpé | Statut manipulé | Analyste nie une clôture | Lecture d'incidents interdits | Requêtes excessives | Rôle lecteur tentant de clore un incident |

Les cases correspondent à des scénarios à analyser, et non à la constatation d'une faille dans le code final. Les exigences suivantes portent sur huit scénarios prioritaires vérifiables par les tests fournis.

## 6. Huit exigences de sécurité testables

### EX-01 — Authentification des événements
Tout message agent **DOIT** être rejeté si sa signature HMAC ne correspond pas à celle calculée avec la clé attendue.
- Menace : **S** sur **TB1** ; Propriété : **I** (authenticité contrôlée)
- Preuve : `tests/test_adapters.py::test_abuse_forged_signature_rejected`

### EX-02 — Refus des données non conformes
Tout message agent **DOIT** être rejeté lorsqu'il contient un champ non autorisé, tel que `is_admin`.
- Menace : **T** sur **TB1** ; Propriété : **I**
- Preuve : `tests/test_adapters.py::test_abuse_extra_field_rejected`

### EX-03 — Traçabilité des notifications
Une notification d'alerte **DOIT** produire une trace d'audit comportant au moins l'identifiant de sa règle.
- Menace : **R** sur **TB3** ; Propriété : **P**
- Preuve : `tests/test_services.py::test_audit_decorator_logs`

### EX-04 — Non-divulgation de la clé
La représentation textuelle de la configuration **NE DOIT** jamais contenir la clé HMAC au format hexadécimal.
- Menace : **I** sur **TB3** (sorties / journaux) ; Propriété : **C**
- Preuve : `tests/test_adapters.py::test_secret_never_printed`

### EX-05 — Limitation des alertes
Avec un quota de trois notifications par fenêtre de 60 secondes, une série de 1 000 alertes **DOIT** envoyer au plus trois notifications et compter 997 rejets.
- Menace : **D** sur **TB3** ; Propriété : **D**
- Preuve : `tests/test_services.py::test_abuse_rate_limiter_absorbs_alert_flood`

### EX-06 — Interdiction de changer le statut sans rôle
Un utilisateur ne disposant que du rôle `viewer` **NE DOIT** pas pouvoir faire passer un incident à l'état `TRIAGED` ; son statut **DOIT** demeurer `OPEN`.
- Menace : **E** sur **TB4** ; Propriété : **I**
- Preuve : `tests/test_services.py::test_abuse_viewer_cannot_close_incident`

### EX-07 — Validation des événements métier
Toute adresse IP invalide, action hors liste autorisée ou identité non conforme **DOIT** provoquer une exception `DomainError` à la création de l'événement.
- Menace : **T** sur **TB1** ; Propriété : **I**
- Preuve : `tests/test_domain.py::test_invalid_event_cannot_exist`

### EX-08 — Robustesse des entrées malveillantes
Le parseur SSH **DOIT** rejeter 1 000 lignes adversariales de la forme testée en moins d'une seconde, sans créer d'événement valide.
- Menace : **D** sur **TB1** ; Propriété : **D**
- Preuve : `tests/test_adapters.py::test_parser_is_fast_on_adversarial_input`

## 7. Vérification de conformité avec la consigne A1

- [x] Au moins 5 actifs (6 définis) et propriétés DICP indiquées.
- [x] Acteurs légitimes, attaquant externe et agent compromis définis.
- [x] DFD orienté flux de données, avec 4 frontières de confiance justifiées.
- [x] Les 6 familles STRIDE apparaissent dans la matrice.
- [x] 8 exigences mesurables avec test nommé.
- [ ] Exécuter les tests : **non effectué à ce stade** ; les composants Python sont à implémenter.

## 8. Sources locales

- `Ateliers_et_consignes_J1_14oct.docx`, atelier A1.
- `J1_14oct_Concevoir_securite_SOLID.pdf`, notions DICP/STRIDE et diagrammes Queen Bee.
- `Guide_pratique_J1_14oct.docx`, format d'exigence et exemples.
- Archive `QueenBee_projet_training (3).zip`, gabarit `docs/threat_model.md`, UML et tests.


---

## 9. Mise à jour Jour 2 — nouveaux parcours et flux

La modélisation reste celle du J1, enrichie par le parcours agent → ingestion →
détection → incident → alerte → triage → blocage → clôture (`docs/architecture_j2.md`).

- **F8** : console SOC → cas d'usage `IncidentService.move` sur TB4. Menace **E** :
  rôle `viewer` tentant une transition ; contrôle du rôle avant toute recherche en base.
- **F9** : cœur → commande de pare-feu via TB3. Menace **T/E** : IP injectée dans
  une commande ; validation `ipaddress`, aucune exécution de chaîne shell dans les tests.
- **F10** : notification → abonnés via TB3. Menaces **D/R** : panne d'abonné et
  absence de comptage ; isolation des pannes, audit et `dropped` vérifiables.
- **F11** : ingestion → adaptateur de traduction des journaux TB1. Menace **D/T** :
  regex pathologique, champ hostile ; longueur bornée puis `fullmatch`, validation métier.

**Points non couverts par le prototype :** MFA réellement déployée, SIEM externe,
pare-feu réel, performances 10 000 événements/s et reprise sous 4 heures.
Les éléments C4 nommés « cible » décrivent l'architecture attendue, non des
intégrations vérifiées localement.

## Extension J3 — revue des 7 failles et correspondance exigence/test (16/10/2026)

La variante de laboratoire `labs/vulnerable_queenbee.py` **reste volontairement vulnérable**, pour permettre les tests pédagogiques locaux, et n'est jamais utilisée par le programme corrigé. Les numéros ci-dessous reprennent les consignes du Jour 3.

| Faille de laboratoire | STRIDE / DICP | Correction dans l'architecture J3 | Test de non-régression | ADR |
|---|---|---|---|---|
| 1 Secret en dur partagé | I / C | `config.py` : clé obligatoire injectée au démarrage, non représentée | `test_j3_fix_01_secret_not_committed_and_injected_at_runtime` | ADR-0002 |
| 2 ReDoS | D / D | `adapters/inbound/log_parser.py` : limite de taille puis `fullmatch` borné | `test_j3_fix_02_bounded_parser_rejects_redos_input` | ADR-0003 |
| 3 pickle | T / I | `adapters/inbound/agent_api.py` : HMAC + JSON strict et taille max | `test_j3_fix_03_signed_json_rejects_untrusted_pickle` | ADR-0004 |
| 4 Injection SQL | T, I / C, I | `adapters/outbound/repositories.py` : SQL paramétré | `test_j3_fix_04_parameterized_sql_keeps_payload_as_data` | ADR-0005 |
| 5 Autorisation absente | E / C, I | `application/services.py` : refus avant tout accès ou écriture | `test_j3_fix_05_authorization_denies_viewer_without_effect` | ADR-0006 |
| 6 Services sans identité | S, T / I | `adapters/inbound/service_auth.py` : simulation de jeton HMAC à durée courte et identité dédiée | `test_j3_fix_06_interservice_auth_before_processing` | ADR-0007 |
| 7 Comparaison jeton non constante | S, I / C | `agent_api.py` et `service_auth.py` : `hmac.compare_digest` | `test_j3_fix_07_hmac_verification_uses_compare_digest` | ADR-0008 |

Les 7 preuves de l'existence des vulnérabilités se trouvent dans `tests/test_lab_vulnerable.py` (3 tests) et `tests/test_j3_lab_extra_proofs.py` (4 tests). Ces tests **réussissent parce que les failles existent dans la variante du laboratoire** ; ce ne sont pas des tests de sécurité d'une version de production. Les sept tests corrigés se trouvent dans `tests/test_j3_security_regressions.py`.

### Nouveaux flux et frontières

- **TB3** : passage application / stockage (accès aux données via un port, droits réduits).
- **TB4** : sortie des événements d'audit vers le SIEM distinct (non effaçable par l'application).
- **TB5** : administration via bastion avec MFA et rôles métier.
- **F2** : appels API d'ingestion ↔ cœur protégés par identité de service (mTLS cible, simulation HMAC dans le code).
- **F7** : sauvegardes et restauration depuis une zone dédiée.

Voir `docs/infrastructure_j3.md` pour la matrice complète et les frontières de confiance à jour. Le TLS/mTLS, le SIEM, PostgreSQL, le bastion et la reprise réelle sont des **choix d'infrastructure cible**, pas des équipements déployés par ce dépôt.
