# ADR 0001 — Monolithe modulaire hexagonal pour Queen Bee

- **Statut :** accepté à titre de choix pédagogique ; validation équipe à confirmer
- **Date :** 15 octobre 2026
- **Décideurs :** groupe Queen Bee (noms à compléter avant remise)

## Contexte

Queen Bee reçoit des événements d'agents SSH/Web/VPN, les valide, déclenche une détection,
conserve les incidents, alerte le SOC et permet une réponse contrôlée. Les données d'entrée
sont non fiables : un agent peut être usurpé ou compromis. Les menaces prioritaires sont S/T/D
à la frontière d'ingestion, E dans les cas d'usage SOC, R sur les actions, et I sur les secrets.

Contraintes connues : **équipe de 3 à 4 étudiants et trois jours** de développement ; tests
exécutables sans réseau ni base externe. L'objectif de **10 000 événements par seconde** évoqué
dans le cours est un objectif de conception, **pas un débit mesuré ni un résultat acquis**.

## Décision

Construire un **monolithe modulaire à architecture hexagonale (ports/adaptateurs)** :
`domain/` contient les invariants, `application/` les cas d'usage et ports (`Protocol`),
`adapters/` les entrées/sorties techniques, et `bootstrap.py` assemble explicitement le système.
Les dépendances pointent vers le domaine. Vérifier cette règle avec `lint-imports`.

Les ports entrants valident la taille, les signatures HMAC et le schéma ; chaque cas d'usage
applique la politique d'autorisation ; les adaptateurs de sortie isolent SQLite, notification,
SIEM et pare-feu de la logique métier.

## Alternatives examinées et écartées

1. **Microservices distribués :** scalabilité et déploiement indépendant possibles, mais multiplication
   des frontières réseau, des identités de service, des secrets et de l'observabilité. Complexité
   disproportionnée pour quatre étudiants et trois jours.
2. **Script monolithique non modulaire :** démarrage simple et peu de fichiers, mais mélange SQL,
   authentification, métier et notifications ; tests difficiles, impact d'une vulnérabilité élargi.

## Conséquences

**Positives :** tests rapides avec doublures en mémoire ; séparation claire du métier ;
remplacement d'un adaptateur sans changer les règles ; réduction des dépendances techniques.

**Négatives assumées :** davantage de classes et de fichiers ; couche d'abstraction à maintenir ;
processus unique représentant un point de panne ; montée en charge horizontale nécessitant
un travail complémentaire ; `import-linter` n'interdit pas tous les effets de bord d'exécution.

## Menaces STRIDE traitées

- **S / TB1 / intégrité :** HMAC avant acceptation des événements.
- **T / TB1 / intégrité :** taille maximale, schéma strict et domaine validé.
- **D / TB1-TB3 / disponibilité :** bornes du parseur et limiteur de notifications.
- **E / TB4 / intégrité :** rôle analyste vérifié avant l'accès à l'incident.
- **R / TB3 / preuve :** audit de notification et exigence d'audit des actions SOC.
- **I / TB3 / confidentialité :** représentation des paramètres sans secret.

## Preuves et limites

- `tests/test_adapters.py::test_abuse_forged_signature_rejected`
- `tests/test_adapters.py::test_abuse_extra_field_rejected`
- `tests/test_j2_defensive.py::test_abuse_proxy_refuses_unauthorized_reader_without_repository_access`
- `tests/test_j2_defensive.py::test_abuse_decorator_absorbs_flood_and_counts_rejections`
- `tests/test_j2_hexagonal.py::test_abuse_viewer_rejected_before_repository_lookup`
- `tests/test_j2_hexagonal.py::test_abuse_sqlite_payload_remains_data`
- `tests/test_adapters.py::test_parser_never_crashes_unexpectedly` (Hypothesis, à exécuter avec dépendances dev)
- `PYTHONPATH=src lint-imports` (à vérifier sur poste équipé de l'outil)

Cette ADR justifie un choix ; elle n'est pas une certification de sécurité ni une preuve
que toutes les exigences non fonctionnelles sont atteintes.
