# ADR-0009 — Segmentation et contrôle des flux

- **Statut** : proposé pour la cible, non déployé.
- **Contexte** : les agents et utilisateurs ne doivent pas avoir un chemin réseau direct vers le cœur ou la base ; les frontières de confiance J1/J2 doivent devenir des règles filtrantes.
- **Décision** : six zones (hôtes, DMZ API, application, données, sécurité, administration), matrice F1–F7, **refus par défaut**, identité par service, console derrière bastion avec MFA.
- **Alternatives écartées** : un seul LAN plat (surface d'attaque accrue), microservices indépendants pour chaque règle (coût disproportionné pour cette formation).
- **Conséquences positives** : chemins lisibles, moindre privilège et simplification des revues.
- **Conséquences négatives** : pare-feu, bastion, certificats, supervision et dépannage augmentent le coût d'exploitation.
- **Menaces** : S, T, I, D, E sur TB1–TB5 ; contrôle indépendant des tests applicatifs.
- **Preuve attendue** : recette firewall en environnement isolé + audit des flux ; non exécutée ici.
