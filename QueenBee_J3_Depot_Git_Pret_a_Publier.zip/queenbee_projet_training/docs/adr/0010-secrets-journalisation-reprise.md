# ADR-0010 — Secrets, audit et reprise

- **Statut** : cible de déploiement, à valider.
- **Contexte** : secrets partagés, journaux effaçables et sauvegardes non testées empêchent d'exploiter durablement Queen Bee.
- **Décision** : coffre à secrets, une identité par service et rotation ; journaux TLS vers SIEM indépendant ; sauvegarde 3-2-1 dont une copie immuable ; RPO 15 minutes, RTO 4 heures.
- **Alternatives écartées** : stockage des secrets dans Git, journalisation seulement en base applicative, sauvegarde locale unique.
- **Conséquences positives** : réduction de l'impact d'une compromission et preuve d'audit préservée.
- **Conséquences négatives** : gestion opérationnelle du coffre, du SIEM, de la rétention et des exercices de restauration.
- **Menaces** : I, R, D ; propriétés confidentialité, preuve, disponibilité.
- **Preuve attendue** : scan de secrets, accès SIEM en lecture seule, test chronométré de reprise en recette. Non exécutée ici.
