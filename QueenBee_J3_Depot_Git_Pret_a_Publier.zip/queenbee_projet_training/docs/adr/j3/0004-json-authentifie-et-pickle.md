# ADR-0004 — JSON authentifié à la place de pickle

- **Statut :** accepté pour la maquette J3, non qualifié production.
- **Contexte :** Une charge pickle peut exécuter du code pendant le chargement.
- **Décision :** Accepter uniquement des corps JSON de taille bornée, signés HMAC et validés contre un schéma.
- **Conséquence positive :** Aucun code arbitraire exécuté par désérialisation.
- **Conséquence négative :** Formats moins flexibles et gestion explicite du schéma.
- **Menace / DICP :** T · intégrité.
- **Preuve locale :** `tests/test_j3_security_regressions.py::test_j3_fix_03_signed_json_rejects_untrusted_pickle`.
