# ADR-0008 — Comparaison HMAC temps constant

- **Statut :** accepté pour la maquette J3, non qualifié production.
- **Contexte :** Une comparaison directe == peut permettre une différence de temps dépendante des caractères.
- **Décision :** Employer hmac.compare_digest pour vérifier les signatures.
- **Conséquence positive :** Supprime la comparaison caractère par caractère de l’application.
- **Conséquence négative :** N’élimine pas toutes les fuites de temps du système.
- **Menace / DICP :** S/C · confidentialité/authenticité.
- **Preuve locale :** `tests/test_j3_security_regressions.py::test_j3_fix_07_hmac_verification_uses_compare_digest`.
