# ADR-0003 — Parseur borné et expression régulière sûre

- **Statut :** accepté pour la maquette J3, non qualifié production.
- **Contexte :** Des entrées volontairement longues provoquent un coût de calcul imprévisible avec la regex vulnérable.
- **Décision :** Vérifier une taille maximale puis appliquer un motif complet et borné.
- **Conséquence positive :** Réduit les risques de ReDoS et d’épuisement CPU.
- **Conséquence négative :** Certains formats de logs non conformes sont rejetés.
- **Menace / DICP :** D · disponibilité.
- **Preuve locale :** `tests/test_j3_security_regressions.py::test_j3_fix_02_bounded_parser_rejects_redos_input`.
