# ADR-0007 — Identité inter-services courte durée

- **Statut :** accepté pour la maquette J3, non qualifié production.
- **Contexte :** Un service d’enrichissement accepte des appels sans identité.
- **Décision :** Simuler une authentification applicative par HMAC propre à chaque service et fenêtre de 30 s ; prévoir mTLS en production.
- **Conséquence positive :** Le traitement refuse tout appel non authentifié ou périmé.
- **Conséquence négative :** Coût d’exploitation des clés ; anti-rejeu complet et TLS non implémentés dans la simulation.
- **Menace / DICP :** S · authenticité/intégrité.
- **Preuve locale :** `tests/test_j3_security_regressions.py::test_j3_fix_06_interservice_auth_before_processing`.
