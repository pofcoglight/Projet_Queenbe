# ADR-0005 — SQL paramétré

- **Statut :** accepté pour la maquette J3, non qualifié production.
- **Contexte :** Des valeurs venant de l’extérieur sont concaténées en SQL.
- **Décision :** Transmettre les paramètres SQL séparément du texte de la requête.
- **Conséquence positive :** Empêche que les valeurs modifient la structure SQL.
- **Conséquence négative :** Le code de persistance nécessite des paramètres explicites.
- **Menace / DICP :** T/I · intégrité et confidentialité.
- **Preuve locale :** `tests/test_j3_security_regressions.py::test_j3_fix_04_parameterized_sql_keeps_payload_as_data`.
