# ADR-0002 — Secret externe par service

- **Statut :** accepté pour la maquette J3, non qualifié production.
- **Contexte :** Un mot de passe en dur et partagé expose tous les services si le dépôt fuit.
- **Décision :** Rendre obligatoire une clé par service fournie à l’exécution, jamais par défaut.
- **Conséquence positive :** Facilite rotation et révocation par service.
- **Conséquence négative :** Exige coffre et orchestration des clés.
- **Menace / DICP :** S/I · confidentialité.
- **Preuve locale :** `tests/test_j3_security_regressions.py::test_j3_fix_01_secret_not_committed_and_injected_at_runtime`.
