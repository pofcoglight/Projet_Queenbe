# ADR-0006 — Autorisation au cas d’usage

- **Statut :** accepté pour la maquette J3, non qualifié production.
- **Contexte :** Une interface peut être contournée si l’autorisation n’existe que dans l’écran.
- **Décision :** Vérifier le rôle analyst avant tout accès et avant la transition d’état.
- **Conséquence positive :** Bloque les modifications non autorisées et les effets de bord.
- **Conséquence négative :** Le service d’application porte la politique d’autorisation.
- **Menace / DICP :** E · confidentialité/intégrité.
- **Preuve locale :** `tests/test_j3_security_regressions.py::test_j3_fix_05_authorization_denies_viewer_without_effect`.
