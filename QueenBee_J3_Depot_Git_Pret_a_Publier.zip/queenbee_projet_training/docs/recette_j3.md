# Queen Bee — Plan de recette et état des preuves J3

## Objectif et périmètre

Recette technique locale du code pédagogique, **pas une homologation de production**. La variante vulnérable est confinée à `labs/`.

## Scénarios rejouables

| ID | Scénario | Critère attendu | Preuve / commande | Statut |
|---|---|---|---|---|
| R1 | Sept failles dans la variante fragile | 7 preuves locales | `python -m pytest -m lab -q` | À relancer sur le poste du groupe |
| R2 | Sept corrections, aucun effet de bord non autorisé | 7 tests verts | `python -m pytest tests/test_j3_security_regressions.py -q` | À relancer sur le poste du groupe |
| R3 | Anciens ateliers J1/J2 sans régression | tests verts | `python -m pytest -q --cov=src/queenbee --cov-fail-under=90` | Suite complète non vérifiée sans Hypothesis |
| R4 | Architecture hexagonale sans import inverse | 1 contrat tenu | `lint-imports` | Non vérifié ici |
| R5 | Qualité / sécurité de code | `ruff`, `mypy`, `bandit` et `pip-audit` | `make check` | Non vérifié ici |
| R6 | Rétablissement après panne de base de recette | RPO ≤ 15 min ; RTO ≤ 4 h | Procédure `docs/infrastructure_j3.md` | Non testé : pas d'infrastructure déployée |
| R7 | Aucun secret réel dans dépôt ou historique | scan sans secret sensible | `gitleaks git .` ou scan de dépôt configuré | Non vérifié ici |

## Décision de livraison

**NO-GO production** tant que R3–R7 ne sont pas vérifiés dans un environnement intégrant les dépendances et les services prévus, et tant que la configuration cible (TLS/mTLS, coffre, SIEM, sauvegardes) n'est pas réellement déployée.

**GO conditionnel pour remise pédagogique J3** uniquement après vérification des tests sur le poste du groupe, relecture des ADR, contrôle de l'historique Git et décision du formateur.

## Lecture correcte des preuves

- Un **test d'exploitation `lab` vert** signifie que la faille de l'exemple vulnérable est démontrée ; ne pas déployer cet exemple.
- Un **test de non-régression vert** montre que le comportement interdit est refusé par le code corrigé du dépôt.
- Un **ADR** décrit un choix justifié, pas sa mise en œuvre réelle.
- Une **matrice réseau** n'est pas un résultat de déploiement ; aucune mesure de RPO/RTO n'est attestée par les fichiers de conception.
