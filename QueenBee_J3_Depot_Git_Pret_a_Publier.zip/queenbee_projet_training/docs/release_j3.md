# Trace de release — Queen Bee J3 (proposition)

Date : 16 octobre 2026 · Module BC3 · version pédagogique 0.3.0+J3

## Inclus dans le périmètre de remise

- Reprise de l'historique J1 (`j1-rendu`) et J2 (`j2-rendu`) **sans réécriture**.
- J3-A1 : sept tests de preuve sur `labs/`, sept tests de régression sur le code corrigé, sept ADR courts (0002–0008).
- J3-A2 : zones, frontières, sept flux justifiés plus refus par défaut, secrets, SIEM, sauvegardes et plan de reprise, ADR 0009–0010.
- J3-A3 : dossier de conception, diagrammes C4 et UML, recette et déclaration des écarts.
- Tag local `j3-rendu` : **à pousser manuellement sur le dépôt du groupe après validation**.

## Écarts / dette assumée

1. Les outils `ruff`, `mypy`, `bandit`, `pip-audit`, `import-linter`, `gitleaks` et les tests Hypothesis doivent être relancés dans un environnement équipé.
2. Une simulation HMAC d'identité inter-services existe ; le mTLS réseau de production et la protection anti-rejeu durable ne sont pas implémentés.
3. PostgreSQL cible, pare-feu réel, SIEM, bastion MFA, coffre à secrets et sauvegardes ne sont pas déployés.
4. RPO 15 min et RTO 4 h restent des objectifs ; aucun exercice de restauration n'a eu lieu.
5. Trois tests historiques des vulnérabilités sont des démonstrations de laboratoire, non des protections ; ne jamais les utiliser sur une cible réelle.

## Décision

**Version pédagogique à remettre seulement après les vérifications locales requises ; NO-GO production.** La livraison ne signifie ni certification de sécurité ni exploitation opérationnelle d'un SOC.
