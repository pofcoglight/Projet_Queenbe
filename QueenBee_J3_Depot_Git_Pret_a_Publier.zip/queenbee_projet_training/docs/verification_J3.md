# Procès-verbal de vérification locale — Queen Bee J3

**Date du contrôle :** 16 octobre 2026 · **Environnement d'exécution :** Linux, Python 3.13.5 · **Objet :** code du dépôt Git J1-J3.

## Exécution locale constatée

| Vérification | Commande | Résultat constaté |
|---|---|---|
| Les 7 preuves du labo | `python -m pytest -m lab -q --ignore=tests/test_adapters.py` | **7 tests réussis** |
| Les régressions et l'ensemble disponible | `python -m pytest --ignore=tests/test_adapters.py --cov=src/queenbee --cov-fail-under=90 -q` | **64 tests réussis, couverture 95,54 %** |
| Syntaxe Python | `python -m compileall -q src tests` | Aucune erreur de compilation constatée |

Les chiffres ci-dessus correspondent **uniquement** aux fichiers exécutables dans cet environnement. Ils ne doivent pas être confondus avec la validation de `make check`.

## Contrôles non exécutés dans l'environnement de préparation

- `tests/test_adapters.py` est exclu parce que la dépendance **Hypothesis** manque ici. La suite **complète** n'a donc pas été vérifiée.
- **Ruff, mypy, Bandit, pip-audit, import-linter, gitleaks** indisponibles localement. Les résultats de qualité, sécurité des dépendances, contrats d'imports et détection de secrets doivent être établis sur le poste Windows après `pip install -e ".[dev]"` (et installation/configuration séparée de gitleaks).
- **Architecture réseau / restauration** : non déployées, non chronométrées ; RPO/RTO spécifiés uniquement comme objectifs dans `infrastructure_j3.md`.

## Remise et décision

Le tag `j3-rendu` désigne ce dossier **pédagogique**. Avant publication, faire contrôler les vrais secrets du dépôt et de son historique, lancer la suite complète et recueillir le retour du formateur.

**Décision : NO-GO pour production ; remise de formation conditionnelle aux contrôles restant à exécuter.**
