# Jour 2 — Parcours utilisateur et choix d'architecture

## 1. Parcours « attaque détectée → incident clos »

| N° | Étape / composante | Frontière | Menace STRIDE | Défense / preuve |
|---|---|---|---|---|
| 1 | Agent SSH : observe 5 échecs | hôte externe | S | identifier agent et source |
| 2 | API d'ingestion : HMAC, taille, schéma | **TB1** | S, T, D | rejet HMAC et champ en trop (`test_adapters.py`) |
| 3 | Domaine : règle force brute | TB1 vers cœur | D | parseur borné, objet validé (`test_domain.py`) |
| 4 | Cas d'usage : incident OPEN | cœur vers **TB2** | T | dépôt et transitions testés (`test_services.py`) |
| 5 | Notificateur : alerte SOC | **TB3** | R, D | audit + limiteur (`test_j2_defensive.py`) |
| 6 | Analyste : triage | **TB4** | E | rôle vérifié avant lecture/écriture (`test_j2_hexagonal.py`) |
| 7 | Commande : blocage IP | **TB3** | T, E | IP validée, action annulable (`test_services.py`) |
| 8 | Analyste : clôture | **TB4**, TB2 | E, R | transition TRIAGED→CLOSED ; audit SOC à compléter |

TB1 = entrée agents ; TB2 = persistance ; TB3 = sortie services externes ;
TB4 = interface humaine SOC. Les flux vers SIEM / pare-feu réels sont des
**cibles d'intégration** : les tests de ce projet utilisent des adaptateurs en mémoire.

## 2. Tranche verticale : cinq échecs SSH par adresse IP

1. **Règle métier :** `BruteForceRule(threshold=5)` émet une alerte `HIGH` pour une IP
   présentant au moins cinq `login_failed` dans l'échantillon analysé. Ce n'est **pas**
   une détection par fenêtre temporelle : une telle exigence nécessiterait une évolution.
2. **Contrat d'interface :** `SecurityEvent` valide IP, utilisateur, action et date à fuseau ;
   l'API d'agent vérifie 4 Kio, HMAC et schéma strict.
3. **Persistance :** `IncidentRepository` définit `save/get/list_open`; SQLite utilise des
   paramètres et stocke l'identifiant, le statut et le contenu de l'alerte.
4. **Restitution :** `Notifier.notify(Alert)` délègue les alertes à une implémentation
   mémoire en test ; la console SOC réelle reste hors périmètre.
5. **Recette :** `test_detection_creates_incident_and_notifies`,
   `test_abuse_viewer_cannot_close_incident`, `test_abuse_rate_limiter_absorbs_alert_flood`.

## 3. Comparaison d'architectures

| Critère | Monolithe hexagonal retenu | Microservices écartés |
|---|---|---|
| Maintenance | Modules et contrats stables | Services indépendants, surcoût d'exploitation |
| Frontières réseau internes | Aucune entre modules | Multiples interfaces réseau |
| Secrets et identités | Centralisés par processus | Identités de service et secrets supplémentaires |
| Tests | Doubles en mémoire, sans réseau | Tests de contrat et intégration distribuée |
| Risques résiduels | Panne du processus, mauvais couplage | Réseau, autorisations interservices, configuration |
| Équipe / délai | Adapté à 3–4 personnes et 3 jours | Disproportionné pour ce projet pédagogique |

Voir `docs/adr/0001-architecture-hexagonale.md` pour la décision, ses avantages,
ses inconvénients assumés et ses preuves. C4 : `docs/uml/c4_context.puml`.
