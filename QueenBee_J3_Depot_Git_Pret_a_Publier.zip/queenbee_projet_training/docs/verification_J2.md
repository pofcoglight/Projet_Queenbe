# Vérification des travaux J2 — Queen Bee

**Date de préparation :** 15 octobre 2026  
**Base de travail :** dépôt J1 avec `j1-rendu` conservé  
**Statut :** préparation avancée, contrôles qualité complets à exécuter sur la machine de remise.

## Ateliers couverts

- A1 : Proxy (accès), Decorator (débit et audit), Adapter (journal SSH), Observer (diffusion), State et Command (cycle d'incident et réponse pare-feu). `tests/test_j2_defensive.py` contient six tests d'abus et un test audit.
- A2 : `docs/architecture_j2.md` (8 étapes, deux frontières au moins, tranche verticale), `docs/adr/0001-architecture-hexagonale.md` (alternative microservices, avantages et coût assumé), `docs/uml/c4_context.puml`, `docs/threat_model.md` enrichi.
- A3 : ports `IncidentRepository`, `Notifier` et `Firewall` en `Protocol` ; cas d'usage `IncidentService.move` ; adaptateurs d'entrée/sortie et tests `tests/test_j2_hexagonal.py`. Le test Hypothesis est dans `tests/test_adapters.py`.

## Tests effectivement exécutés ici

1. `python -m pytest -q tests/test_services.py tests/test_j2_defensive.py tests/test_j2_hexagonal.py` : **23 réussis**.
2. `python -m pytest -q --ignore=tests/test_adapters.py --cov=src/queenbee --cov-fail-under=90` : **53 réussis**, couverture **97,03 %** sur les tests exécutés.

L'environnement de contrôle utilisé était Linux, Python 3.13.5. Le temps mesuré pour la suite avec couverture est de l'ordre de 2 à 3 secondes, **pas** une preuve que la suite complète respecte l'objectif de moins de deux secondes.

## Non vérifié dans cet environnement

- `tests/test_adapters.py` **non exécuté** : Hypothesis indisponible (aucun accès aux dépendances).
- `lint-imports`, `ruff`, `mypy`, `bandit`, `pip-audit`, `make check` : outils non disponibles ici. Le contrat `layers` existe dans `pyproject.toml`, sans vérification instrumentée.
- Aucune intégration réelle de SIEM, pare-feu de production ou MFA. Les adaptateurs mémoire et SQLite embarqué sont des éléments pédagogiques.
- Aucun `git push` distant n'a été réalisé. Le tag `j2-rendu` reste **local** jusqu'à publication par l'étudiant.

## Actions avant remise au formateur

- Installer Python 3.13 et les dépendances dev : `python -m pip install -e ".[dev]"`.
- Exécuter `python -m pytest tests/test_services.py tests/test_adapters.py -q`.
- Exécuter `python -m pytest -k abuse -q`, puis toutes les vérifications `make check` (ou commandes équivalentes sur Windows).
- Représenter le contexte C4 en PlantUML ; adapter le nom des décideurs et les éventuelles hypothèses du groupe.
- Vérifier l'absence de secrets réels, le dépôt GitHub du groupe et le tag `j2-rendu`.

**Ne pas présenter ces résultats partiels comme une validation totale du J2.**
