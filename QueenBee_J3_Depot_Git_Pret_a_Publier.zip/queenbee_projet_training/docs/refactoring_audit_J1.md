# Atelier A2 — Audit du script hérité et refactoring SOLID

**Source examinée :** `legacy/log_watcher.py` (script pédagogique volontairement vulnérable).

| Ligne / zone héritée | Problème SOLID ou sécurité | Conséquence | Correction J1 |
|---|---|---|---|
| `SMTP_PASSWORD = "..."` | Secret en clair dans les sources | Secret exposé dans le dépôt et son historique | `config.SettingsBuilder` exige une clé fournie séparément ; `.env` exclu par `.gitignore` |
| `DB = sqlite3.connect(...)` | État global et couplage (DIP) | Tests dépendants du même état et effet de bord à l'import | Port `IncidentRepository` et injection dans `DetectionService` |
| `LogWatcher.run()` | SRP : parsing, détection, accès BD, notification mélangés | Modification de la source ou de la BD affecte la détection | `log_parser`, `domain.rules`, `application.services`, `outbound.*` |
| `re.search(r"... (.*) ...")` | Motif gourmand et non ancré | Entrées inattendues acceptées, données non fiables | Parser borné à 512 caractères, regex ancrée et champs contrôlés |
| `open(self.path)` | Descripteur non géré, taille non bornée | Ressources non libérées ; entrée sans plafond | Lecture contrôlée déléguée à un adaptateur ; fonction `parse_sshd_line` n'ouvre pas de fichier |
| `DB.execute(f"INSERT ...")` | SQL construit depuis une adresse IP contrôlée par autrui | Injection SQL | `SqliteIncidentRepository.save/get/list_open` utilise `?` et des paramètres |
| `smtplib.SMTP(...)` dans la classe | DIP / SRP : infrastructure imposée au métier | Tests impliquant un réseau réel, dépendances fragiles | Port `Notifier` et injection d'un adaptateur mémoire |
| `if kind == 'csv' ... elif ...` | OCP : nouveaux formats = modification de la classe | Risque de régression lors de l'ajout d'un format | Responsabilités de restitution retirées du domaine ; futur adaptateur par format |
| `report('html')` sans échappement | Risque d'injection HTML | Affichage non sûr si utilisé en page web | Supprimer la génération HTML ad hoc ; échappement à assurer dans l'interface web future |
| `if counts[ip] == 5` | Seuil et règle figés, logique métier enfouie | Réutilisation difficile pour nouvelles attaques | `BruteForceRule(threshold=5)` et `PortScanRule` via `RuleSet` |

## Plan de migration

1. **Filet de sécurité :** deux tests de caractérisation dans `tests/test_legacy_characterization_j1.py` ; SMTP remplacé par un espion, aucun serveur réel.
2. **Domaine pur :** objets-validés (`SecurityEvent`, `Alert`, `Incident`) dans `src/queenbee/domain/model.py` ; règles de détection sans `sqlite3`, `smtplib`, ni effet réseau.
3. **Ports :** `IncidentRepository` et `Notifier` en `typing.Protocol` dans `application/ports.py` ; les cas d'usage ne connaissent que ces contrats.
4. **Séparation des effets :** dépôts en mémoire ou SQLite, notificateur mémoire ; les services reçoivent leurs dépendances en arguments.
5. **Création sous contrôle :** Factory avec registre explicite, Builder validant une configuration figée, copie via `dataclasses.replace`, composition sans Singleton.

## Traçabilité des changements

- `legacy/` est volontairement préservé pour les exercices ; **ne pas déployer**.
- Les tests d'origine du formateur n'ont pas été modifiés.
- Le code de production dans `src/` ne contient ni secret en clair ni f-string SQL.
- Le notifier de « production » fourni est un **adaptateur mémoire pédagogique**, pas un canal SOC de production.
- Les traitements persistants et les contrôles RBAC complets feront l'objet d'une validation approfondie au J2.

## Risque restant

HMAC n'empêche pas un **agent déjà compromis** de signer des événements trompeurs avec sa clé valide ; détection comportementale, révocation des clés et cloisonnement restent nécessaires. `repr=False` empêche l'affichage automatique d'une clé via `repr()`, **pas** sa divulgation par des logs manuels ou des dumps mémoire. Les notifications d'audit en mémoire ne prouvent pas la non-répudiation à elles seules.
