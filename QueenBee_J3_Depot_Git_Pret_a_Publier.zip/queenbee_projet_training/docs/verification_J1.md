# Procès-verbal de vérification — rendu J1

Date : 14 octobre 2026. Environnement de validation : Python 3.13.5, Linux, `pytest` et `pytest-cov` disponibles.

## Contrôles exécutés

| Contrôle | Résultat |
|---|---|
| Tests originaux J1 `tests/test_domain.py` et `tests/test_creational.py` | **14 réussis** |
| Tests J1 ajoutés : caractérisation legacy, abus, limites d'entrée | **13 réussis** (2 + 4 + 7) |
| Tests d'origine J2 `tests/test_services.py` | **8 réussis** |
| Tests J3 `tests/test_lab_vulnerable.py` (démonstration des vulnérabilités de laboratoire) | **3 réussis** |
| Ensemble explicitement exécuté (sans `test_adapters.py`) | **38 réussis** |
| Couverture `pytest-cov` avec cet ensemble | **96,93 %** pour `src/queenbee` ; minimum 90 % atteint **sur l'ensemble exécuté** |
| Compilation Python `compileall -q src tests` | **réussie** |
| Rejet de 1 000 lignes SSH adversariales | **1 000 rejets en 0,00088 s** (mesure locale, non garantie sur une autre machine) |

Les **tests fournis par le formateur n'ont pas été modifiés**. Les deux tests de caractérisation du script ancien sont indépendants du serveur SMTP réel.

## Contrôles non vérifiables ici

- **`tests/test_adapters.py`** : import de `hypothesis`, paquet absent ; collecte impossible dans cet environnement. Des contrôles de sécurité équivalents ont été écrits et exécutés séparément, mais ils **ne remplacent pas** la suite fournie.
- **Ruff, mypy, Bandit, pip-audit, import-linter** : non présents et impossible à télécharger depuis l'environnement de création (accès réseau externe désactivé).
- Par conséquent **`make check` et les portes qualité complètes ne sont PAS attestés verts**. Les lancer sur le poste du groupe après `pip install -e ".[dev]"`.
- **Push distant** : non réalisé, car aucune URL de dépôt/autorisation n'a été fournie. Un tag local de démonstration est inclus dans le dépôt livré.

## Remarques de sécurité et limites

- Aucun secret réel n'a été ajouté aux sources. La chaîne `SMTP_PASSWORD` dans `legacy/` est un exemple **fictif préexistant**, délibérément vulnérable et exclu de la zone de code de production `src/`.
- La base SQLite utilise des requêtes paramétrées ; le domaine ne dépend ni de `sqlite3` ni de `smtplib`.
- Un adaptateur `ProdFactory` retourne un notifier mémoire pour la formation ; ce n'est pas une notification SOC en conditions réelles.
- `repr=False` masque la clé dans la représentation automatique, mais ne garantit pas une confidentialité absolue hors de ce contexte.
- Les tests J3 valident volontairement des failles présentes dans `labs/` ; cela n'implique **pas** que les failles sont corrigées à J1.

## Statut final

Le contenu demandé pour les ateliers **A1, A2 et A3 est préparé**, avec tests J1 réussis. **Validation et publication finales conditionnées** au lancement de la chaîne qualité complète sur le poste du groupe et au `git push` du tag.
