# Queen Bee — J3 A2 : infrastructure cible (CONCEPTION, NON DÉPLOYÉE)

> Statut : architecture proposée pour le dossier. Aucune machine, configuration réseau ou restauration réelle n'a été déployée/testée ici.

## Zones et frontières

| Zone | Rôle | Protection / frontière |
|---|---|---|
| Z0 Hôtes surveillés | Agents SSH, Web, VPN | Hors confiance, événements signés |
| Z1 DMZ d'ingestion | API des agents, validation HMAC | TB1, API exposée uniquement en HTTPS |
| Z2 Zone applicative | Cas d'usage et moteur Queen Bee | TB2, identité de service par appel |
| Z3 Zone données | Base PostgreSQL cible | TB3, accès strict au compte `qb_app` |
| Z4 Zone sécurité | SIEM et sauvegardes | TB4, stockage de journaux séparé et non supprimable par l'application |
| Z5 Administration | Bastion et console SOC | TB5, MFA et contrôle des rôles |

La persistance **SQLite actuelle est pédagogique**. PostgreSQL est un **choix cible envisagé**, pas un adaptateur ni une migration déjà réalisés.

## Matrice des flux — politique : refuser tout flux non listé

| ID | Source → Destination | Protocole / port cible | Justification applicative | STRIDE |
|---|---|---|---|---|
| F1 | Agents Z0 → API Z1 | HTTPS 443, TLS 1.3 | `parse_agent_message` : limite taille, HMAC, JSON | S, T, D |
| F2 | API Z1 → Cœur Z2 | interne TLS/mTLS (port à définir au déploiement) | `DetectionService.ingest`, identité du service | S, E |
| F3 | Cœur Z2 → Base Z3 | PostgreSQL 5432 + TLS | Port `IncidentRepository`, compte applicatif minimal | T, I |
| F4 | Cœur Z2 → Pare-feu | API HTTPS 443 + mTLS | Port `Firewall` et commande `BlockIpCommand` | T, E |
| F5 | Cœur Z2 → SIEM Z4 | syslog TLS 6514 | `AuditedNotifier` / journalisation | R |
| F6 | Bastion Z5 → Console SOC | HTTPS 443 + MFA | Autorisation `IncidentService.move` | S, E |
| F7 | Système sauvegarde Z4 → Base Z3 | canal chiffré administré, port à préciser | Sauvegarde / restauration, RPO-RTO | D |
| Défaut | Tous les autres flux | **REFUSÉ** | Politique de moindre privilège | Tous |

**Règle d'administration :** aucun accès direct des utilisateurs à la base Z3 ; chaque requête transite par le cas d'usage. La console n'obtient pas les secrets des agents. `qb_app` ne possède ni droits DDL ni droits de suppression des journaux du SIEM.

## Secrets et identités

- Une clé différente pour chaque agent et chaque service, fournie par coffre au démarrage.
- Une politique de rotation, date d'expiration, révocation d'urgence et audit d'accès au coffre est requise avant production.
- Pas de valeur secrète par défaut. Dans le dépôt training : `.env` ignoré ; `settings_from_env` échoue si clé absente.
- La démonstration locale d'authentification inter-services utilise **HMAC avec clé distincte et durée courte** ; elle ne constitue pas une implémentation de mTLS.

## Audit et exploitation

- Journaliser auteur, action, date, cible, décision d'accès, origine et compte de rejets.
- **Ne jamais journaliser** les clés, mots de passe, signatures brutes, données personnelles non nécessaires.
- Acheminer vers SIEM séparé en TLS ; l'application ne peut pas modifier/supprimer ces traces.
- Prévoir corrélation, rétention, supervision et alarmes sur pertes d'événements.

## Continuité et sauvegarde — objectifs *proposés*

- Disponibilité cible : 99,5 % (objectif à valider avec le métier).
- **RPO** : 15 minutes (perte de données maximale visée).
- **RTO** : 4 heures (durée de reprise maximale visée).
- Politique 3-2-1, avec une copie hors site et une copie immuable ; chiffrement des sauvegardes.

### Scénario de test de reprise (À EXÉCUTER, NON VALIDÉ)

1. Créer et horodater des incidents de recette ; noter le dernier point de restauration connu.
2. Simuler la panne **uniquement sur la base de recette** ; lancer le chronomètre.
3. Restaurer depuis une sauvegarde vérifiée ; redémarrer les services en environnement isolé.
4. Vérifier intégrité, droits, liens vers les incidents, et présence des journaux SIEM.
5. Mesurer l'écart réel entre dernier écrit restauré et heure de panne (RPO), ainsi que le temps de reprise (RTO).
6. Documenter les mesures et décisions ; si RPO > 15 min ou RTO > 4 h, déclaration de non-conformité.

Aucune valeur RPO/RTO mesurée ne figure dans ce rendu : il s'agit de cibles et d'un protocole, pas d'une preuve de reprise réussie.
