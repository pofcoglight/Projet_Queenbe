# Queen Bee — livrable Jour 1 (14 octobre 2026)

**BC3 — Architecture logicielle · ITIS MAST CYBER 4 / MAST DEV 4**

## Contenu du rendu

| Atelier | Fichier(s) | État vérifiable |
|---|---|---|
| A1 — STRIDE | `docs/threat_model.md` | 6 actifs, acteurs, DFD, 4 frontières, six catégories STRIDE, 8 exigences avec tests nommés |
| A2 — Refactoring SOLID | `docs/refactoring_audit_J1.md`, `src/queenbee/domain/`, `src/queenbee/application/ports.py`, adaptateurs de soutien | 10 problèmes relevés, 2 tests de caractérisation, domaine indépendant de SQLite/SMTP |
| A3 — Patterns | `src/queenbee/domain/rules.py`, `src/queenbee/config.py`, `src/queenbee/factories.py`, `src/queenbee/bootstrap.py` | Factory par registre, Builder figé, Fabrique abstraite, Prototype, pas de Singleton |
| Qualité | `tests/test_j1_*.py`, `docs/verification_J1.md` | Tests réellement lancés et contrôles non vérifiés décrits séparément |

**Important :** `legacy/` et `labs/` sont intentionnellement vulnérables et conservés inchangés pour les exercices ; ils ne doivent pas être déployés. Les tests livrés initialement par le formateur sont conservés inchangés. Les supports généraux restent disponibles dans le ZIP d'origine.

## Installation sous Windows PowerShell

Depuis le dossier `queenbee_projet_training` :

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -e ".[dev]"
python -m pytest tests/test_domain.py tests/test_creational.py -q
python -m pytest tests/test_legacy_characterization_j1.py tests/test_j1_security_additions.py tests/test_j1_boundary_security.py -q
```

Si Python 3.13 est installé, remplacer `py -3.12` par `py -3.13`. L'installation des dépendances requiert un accès aux index de paquets.

## Vérifications complètes à faire sur le PC du groupe

```powershell
ruff check .
ruff format --check .
mypy
python -m pytest --cov=src/queenbee --cov-fail-under=90
bandit -q -r src -c pyproject.toml
pip-audit
$env:PYTHONPATH="src"; lint-imports
```

Ne pas modifier les tests du formateur pour contourner un échec. Corriger les problèmes éventuels, relancer toutes les vérifications, puis pousser le tag de rendu :

```powershell
git status
git tag --list j1-rendu
git remote -v
# Après avoir configuré le dépôt distant et vérifié les contrôles :
git push origin HEAD
git push origin j1-rendu
```

Le tag `j1-rendu` fourni est **local** ; aucun `push` n'a été effectué et aucun résultat de CI distant n'a été inventé.

## Ce qui dépasse légèrement le J1

Les tests `test_creational.py` (annoncés J1) importent déjà `application.services` et `adapters.outbound`. Des implémentations minimales cohérentes avec les tests ont donc été ajoutées, de même que quelques composants d'intégration servant à documenter les exigences de sécurité. Elles constituent une base **pédagogique**, pas une certification d'aptitude à la production ni le rendu J2/J3.
