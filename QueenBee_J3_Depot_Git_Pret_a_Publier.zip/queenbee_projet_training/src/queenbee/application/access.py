"""Role-based read proxy: permissions checked at every use case."""

from __future__ import annotations

from queenbee.application.ports import IncidentRepository
from queenbee.application.services import AccessDeniedError
from queenbee.domain.model import Incident, Principal


class IncidentReadProxy:
    def __init__(self, repository: IncidentRepository, principal: Principal) -> None:
        self._repository = repository
        self._principal = principal

    def list_open(self) -> list[Incident]:
        if not (self._principal.roles & {"analyst", "viewer", "admin"}):
            raise AccessDeniedError("Incident reading requires an authorized role")
        return self._repository.list_open()
