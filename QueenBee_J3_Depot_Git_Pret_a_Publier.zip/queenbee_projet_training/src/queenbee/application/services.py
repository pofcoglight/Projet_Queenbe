"""Application use cases separated from databases and notifications."""

from __future__ import annotations

from collections.abc import Sequence
from uuid import UUID

from queenbee.application.ports import IncidentRepository, Notifier
from queenbee.domain.model import DomainError, Incident, IncidentStatus, Principal, SecurityEvent
from queenbee.domain.rules import DetectionRule


class AccessDeniedError(PermissionError):
    """The principal lacks the required role."""


class DetectionService:
    def __init__(
        self, rule: DetectionRule, repository: IncidentRepository, notifiers: Sequence[Notifier]
    ) -> None:
        self._rule = rule
        self._repository = repository
        self._notifiers = tuple(notifiers)

    def ingest(self, events: Sequence[SecurityEvent]) -> list[Incident]:
        incidents: list[Incident] = []
        for alert in self._rule.evaluate(events):
            incident = Incident(alert)
            self._repository.save(incident)
            for notifier in self._notifiers:
                notifier.notify(alert)
            incidents.append(incident)
        return incidents


class IncidentService:
    def __init__(self, repository: IncidentRepository) -> None:
        self._repository = repository

    def move(self, principal: Principal, incident_id: UUID, status: IncidentStatus) -> Incident:
        if "analyst" not in principal.roles:
            raise AccessDeniedError("Only analysts may change an incident")
        incident = self._repository.get(incident_id)
        if incident is None:
            raise DomainError("Unknown incident")
        incident.transition_to(status)
        self._repository.save(incident)
        return incident
