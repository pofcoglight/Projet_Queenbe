"""Validated immutable configuration; secrets never appear in repr()."""

from __future__ import annotations

import os
from collections.abc import Mapping
from dataclasses import dataclass, field, replace


class ConfigError(ValueError):
    """Configuration is incomplete or invalid."""


@dataclass(frozen=True, slots=True)
class Settings:
    agent_hmac_key: bytes = field(repr=False)
    database_path: str = ":memory:"
    max_notifications: int = 10

    def __post_init__(self) -> None:
        if not isinstance(self.agent_hmac_key, bytes) or len(self.agent_hmac_key) < 32:
            raise ConfigError("At least 32 bytes of HMAC key are required")
        if not self.database_path:
            raise ConfigError("Database path required")
        if type(self.max_notifications) is not int or self.max_notifications <= 0:
            raise ConfigError("Notification rate must be a positive integer")


class SettingsBuilder:
    def __init__(self) -> None:
        self._key: bytes | None = None
        self._db_path = ":memory:"
        self._max_notifications = 10

    def hmac_key(self, key: bytes) -> SettingsBuilder:
        self._key = key
        return self

    def database_path(self, path: str) -> SettingsBuilder:
        self._db_path = path
        return self

    def max_notifications(self, count: int) -> SettingsBuilder:
        self._max_notifications = count
        return self

    def build(self) -> Settings:
        if self._key is None:
            raise ConfigError("Missing agent HMAC key")
        return Settings(self._key, self._db_path, self._max_notifications)


def settings_from_env(environment: Mapping[str, str] | None = None) -> Settings:
    source = os.environ if environment is None else environment
    raw_key = source.get("QUEENBEE_AGENT_KEY", "")
    try:
        key = bytes.fromhex(raw_key)
    except ValueError as exc:
        raise ConfigError("HMAC key must be hexadecimal") from exc
    return SettingsBuilder().hmac_key(key).build()


def copy_settings(settings: Settings, **changes: object) -> Settings:
    """Prototype: dataclasses.replace revalidates the new configuration."""
    return replace(settings, **changes)
