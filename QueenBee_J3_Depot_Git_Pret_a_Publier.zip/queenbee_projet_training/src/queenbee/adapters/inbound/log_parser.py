"""Bounded, strictly validated sshd log parser (no permissive search)."""

from __future__ import annotations

import re
from datetime import datetime

from queenbee.domain.model import DomainError, SecurityEvent

# Anchored and deliberately restricted, avoiding nested repetitions and .* .
_SSHD = re.compile(
    r"\A(?P<when>\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}[+-]\d{2}:\d{2}) "
    r"sshd: Failed password for (?P<user>[A-Za-z0-9_.@-]{1,64}) "
    r"from (?P<ip>[0-9A-Fa-f:.]{3,45})\Z",
    flags=re.ASCII,
)


def parse_sshd_line(line: str) -> SecurityEvent:
    if not isinstance(line, str) or not 0 < len(line) <= 512:
        raise DomainError("Invalid SSH log line size")
    match = _SSHD.fullmatch(line)
    if match is None:
        raise DomainError("Malformed SSH log line")
    try:
        timestamp = datetime.fromisoformat(match["when"])
    except ValueError as exc:
        raise DomainError("Invalid SSH timestamp") from exc
    return SecurityEvent(match["ip"], match["user"], "login_failed", timestamp)
