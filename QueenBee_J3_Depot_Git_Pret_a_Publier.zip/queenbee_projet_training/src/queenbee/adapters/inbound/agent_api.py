"""HMAC-authenticated strict JSON ingestion boundary."""

from __future__ import annotations

import hashlib
import hmac
import json
from datetime import datetime

from queenbee.domain.model import DomainError, SecurityEvent


class UnauthenticatedError(PermissionError):
    """Message authenticity failed."""


def sign(body: bytes, key: bytes) -> bytes:
    return hmac.new(key, body, hashlib.sha256).digest()


def parse_agent_message(body: bytes, signature: bytes, key: bytes) -> SecurityEvent:
    if len(body) > 4096:
        raise DomainError("Agent message exceeds 4 KiB")
    if not hmac.compare_digest(sign(body, key), signature):
        raise UnauthenticatedError("Invalid agent signature")
    try:
        payload = json.loads(body)
        if not isinstance(payload, dict):
            raise DomainError("Expected a JSON object")
        if set(payload) != {"source_ip", "username", "action", "timestamp"}:
            raise DomainError("Missing or additional fields in agent message")
        if not all(isinstance(value, str) for value in payload.values()):
            raise DomainError("All event fields must be strings")
        return SecurityEvent(
            payload["source_ip"], payload["username"], payload["action"],
            datetime.fromisoformat(payload["timestamp"]),
        )
    except (ValueError, UnicodeDecodeError, TypeError, KeyError) as exc:
        if isinstance(exc, DomainError):
            raise
        raise DomainError("Invalid agent message") from exc
