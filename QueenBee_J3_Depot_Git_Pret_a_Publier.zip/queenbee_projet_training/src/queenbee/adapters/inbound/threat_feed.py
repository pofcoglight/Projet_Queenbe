"""Anti-corruption layer for an external threat indicator feed."""

from __future__ import annotations

import ipaddress
from dataclasses import dataclass
from typing import Any

from queenbee.domain.model import DomainError


@dataclass(frozen=True, slots=True)
class ThreatIndicator:
    ip_address: str
    score: int


class ThreatFeedTranslator:
    _scores = {"low": 20, "medium": 50, "high": 80, "critical": 100}

    def translate(self, item: dict[str, Any]) -> ThreatIndicator:
        ip = item.get("indicator")
        risk = item.get("risk_level")
        if not isinstance(ip, str) or not isinstance(risk, str) or risk not in self._scores:
            raise DomainError("Invalid threat-feed fields")
        try:
            ipaddress.ip_address(ip)
        except ValueError as exc:
            raise DomainError("Threat-feed indicator must be an IP address") from exc
        return ThreatIndicator(ip, self._scores[risk])
