"""Authenticated local simulation of inter-service enrichment (J3, issue 6).

Transport security is deliberately out of scope: a production HTTPS endpoint
must also enforce TLS/mTLS, rotate credentials and prevent replay as required.
"""

from __future__ import annotations

import hashlib
import hmac
import ipaddress
import json
import time
from collections.abc import Callable, Mapping
from dataclasses import dataclass


class ServiceAuthenticationError(PermissionError):
    """Missing, expired or forged service-to-service identity."""


@dataclass(frozen=True, slots=True)
class EnrichmentRequest:
    service: str
    ip: str
    issued_at: int


def encode_enrichment_request(service: str, ip: str, issued_at: int, key: bytes) -> tuple[bytes, bytes]:
    """Encode and sign a request; each caller supplies its own secret key."""
    body = json.dumps(
        {"service": service, "ip": ip, "issued_at": issued_at},
        separators=(",", ":"), sort_keys=True,
    ).encode("utf-8")
    return body, hmac.new(key, body, hashlib.sha256).digest()


class AuthenticatedEnrichmentService:
    """Validate caller identity before returning any data or recording a call."""

    def __init__(
        self,
        service_keys: Mapping[str, bytes],
        *,
        clock: Callable[[], float] = time.time,
        max_age_seconds: int = 30,
    ) -> None:
        if not service_keys or type(max_age_seconds) is not int or max_age_seconds <= 0:
            raise ValueError("Service authentication configuration invalid")
        if not all(
            isinstance(name, str) and name and isinstance(key, bytes) and len(key) >= 32
            for name, key in service_keys.items()
        ):
            raise ValueError("Every authorized service requires a distinct valid key")
        if len(set(service_keys.values())) != len(service_keys):
            raise ValueError("Services must not share authentication keys")
        self._keys = dict(service_keys)
        self._clock = clock
        self._max_age_seconds = max_age_seconds
        self.calls = 0

    def enrich(self, body: bytes, signature: bytes) -> dict[str, str]:
        """Reject unauthorized calls *before* any enrichment operation."""
        if not isinstance(body, bytes) or len(body) > 512 or not isinstance(signature, bytes):
            raise ServiceAuthenticationError("Invalid request size or signature")
        try:
            payload = json.loads(body)
        except (ValueError, UnicodeDecodeError, TypeError) as exc:
            raise ServiceAuthenticationError("Malformed service message") from exc
        if not isinstance(payload, dict) or set(payload) != {"service", "ip", "issued_at"}:
            raise ServiceAuthenticationError("Unexpected service message schema")
        service = payload["service"]
        ip = payload["ip"]
        issued_at = payload["issued_at"]
        if (
            not isinstance(service, str) or service not in self._keys
            or not isinstance(ip, str) or type(issued_at) is not int
        ):
            raise ServiceAuthenticationError("Invalid caller identity or fields")
        expected = hmac.new(self._keys[service], body, hashlib.sha256).digest()
        if not hmac.compare_digest(expected, signature):
            raise ServiceAuthenticationError("Invalid signature")
        now = self._clock()
        if issued_at > now or now - issued_at > self._max_age_seconds:
            raise ServiceAuthenticationError("Expired or future-dated request")
        try:
            ipaddress.ip_address(ip)
        except ValueError as exc:
            raise ServiceAuthenticationError("Invalid enrichment IP") from exc
        self.calls += 1
        return {"ip": ip, "reputation": "unknown"}
