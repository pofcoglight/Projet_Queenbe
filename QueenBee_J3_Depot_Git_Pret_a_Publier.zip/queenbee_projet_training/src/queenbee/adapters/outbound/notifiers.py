"""Notifier adapters, with in-memory test double and safe wrappers."""

from __future__ import annotations

import logging
import time
from collections.abc import Callable

from queenbee.application.ports import Notifier
from queenbee.domain.model import Alert, DomainError


class MemoryNotifier:
    def __init__(self) -> None:
        self.received: list[Alert] = []

    def notify(self, alert: Alert) -> None:
        self.received.append(alert)


class AuditedNotifier:
    def __init__(self, wrapped: Notifier) -> None:
        self._wrapped = wrapped

    def notify(self, alert: Alert) -> None:
        self._wrapped.notify(alert)
        logging.getLogger("queenbee.audit").info("Alert delivered: rule=%s", alert.rule)


class RateLimitedNotifier:
    def __init__(
        self,
        wrapped: Notifier,
        max_per_window: int,
        window_s: float,
        clock: Callable[[], float] = time.monotonic,
    ) -> None:
        if type(max_per_window) is not int or max_per_window < 1 or window_s <= 0:
            raise DomainError("Invalid notification rate limit")
        self._wrapped = wrapped
        self._max = max_per_window
        self._window_s = window_s
        self._clock = clock
        self._start = clock()
        self._count = 0
        self.dropped = 0

    def notify(self, alert: Alert) -> None:
        now = self._clock()
        if now - self._start >= self._window_s:
            self._start, self._count = now, 0
        if self._count >= self._max:
            self.dropped += 1
            return
        self._count += 1
        self._wrapped.notify(alert)


class ObserverNotifier:
    """Broadcast alerts to registered subscribers; one faulty subscriber is isolated."""

    def __init__(self) -> None:
        self._subscribers: list[Notifier] = []
        self.failures = 0

    def subscribe(self, subscriber: Notifier) -> None:
        self._subscribers.append(subscriber)

    def notify(self, alert: Alert) -> None:
        for subscriber in tuple(self._subscribers):
            try:
                subscriber.notify(alert)
            except Exception:  # one failed integration must not block other subscribers
                self.failures += 1
                logging.getLogger("queenbee.audit").exception(
                    "Notifier subscriber failed for rule=%s", alert.rule
                )
