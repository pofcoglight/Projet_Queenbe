"""In-memory and SQLite persistence implementations."""

from __future__ import annotations

import sqlite3
from uuid import UUID

from queenbee.domain.model import Alert, Incident, IncidentStatus, Severity


class InMemoryIncidentRepository:
    def __init__(self) -> None:
        self._data: dict[UUID, Incident] = {}

    def save(self, incident: Incident) -> None:
        self._data[incident.id] = incident

    def get(self, incident_id: UUID) -> Incident | None:
        return self._data.get(incident_id)

    def list_open(self) -> list[Incident]:
        return [i for i in self._data.values() if i.status != IncidentStatus.CLOSED]


class SqliteIncidentRepository:
    def __init__(self, connection: sqlite3.Connection | str) -> None:
        self._db = sqlite3.connect(connection) if isinstance(connection, str) else connection
        self._db.execute(
            "CREATE TABLE IF NOT EXISTS incidents ("
            "id TEXT PRIMARY KEY, rule TEXT, ip TEXT, severity INTEGER, "
            "message TEXT, status TEXT)"
        )
        self._db.commit()

    def save(self, incident: Incident) -> None:
        self._db.execute(
            "INSERT OR REPLACE INTO incidents "
            "(id, rule, ip, severity, message, status) VALUES (?, ?, ?, ?, ?, ?)",
            (
                str(incident.id), incident.alert.rule, incident.alert.source_ip,
                int(incident.alert.severity), incident.alert.message, incident.status.value,
            ),
        )
        self._db.commit()

    @staticmethod
    def _incident(row: tuple[str, str, str, int, str, str]) -> Incident:
        id_, rule, ip, severity, message, status = row
        return Incident(
            Alert(rule, ip, Severity(severity), message), UUID(id_), IncidentStatus(status)
        )

    def get(self, incident_id: UUID) -> Incident | None:
        result = self._db.execute(
            "SELECT id, rule, ip, severity, message, status FROM incidents WHERE id = ?",
            (str(incident_id),),
        ).fetchone()
        return self._incident(result) if result else None

    def list_open(self) -> list[Incident]:
        rows = self._db.execute(
            "SELECT id, rule, ip, severity, message, status FROM incidents WHERE status != ?",
            (IncidentStatus.CLOSED.value,),
        ).fetchall()
        return [self._incident(row) for row in rows]
