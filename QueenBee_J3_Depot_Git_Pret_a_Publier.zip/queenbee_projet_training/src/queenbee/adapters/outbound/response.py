"""Undoable firewall command: never execute a shell string from an event."""

from __future__ import annotations

import ipaddress
from queenbee.application.ports import Firewall


class InMemoryFirewall:
    def __init__(self) -> None:
        self.blocked: set[str] = set()

    def block(self, ip: str) -> None:
        self.blocked.add(ip)

    def unblock(self, ip: str) -> None:
        self.blocked.discard(ip)


class BlockIpCommand:
    def __init__(self, firewall: Firewall, ip: str) -> None:
        try:
            ipaddress.ip_address(ip)
        except ValueError as exc:
            raise ValueError("IP does not appear to be valid") from exc
        self._firewall = firewall
        self._ip = ip

    def execute(self) -> None:
        self._firewall.block(self._ip)

    def undo(self) -> None:
        self._firewall.unblock(self._ip)


class CommandHistory:
    def __init__(self) -> None:
        self._history: list[BlockIpCommand] = []

    def run(self, command: BlockIpCommand) -> None:
        command.execute()
        self._history.append(command)

    def undo_last(self) -> None:
        if not self._history:
            raise ValueError("No command to undo")
        self._history.pop().undo()
