"""Abstract factories build coherent persistence/notification families."""

from __future__ import annotations

from typing import Protocol

from queenbee.adapters.outbound.notifiers import MemoryNotifier
from queenbee.adapters.outbound.repositories import InMemoryIncidentRepository, SqliteIncidentRepository
from queenbee.application.ports import IncidentRepository, Notifier


class ComponentFactory(Protocol):
    def repository(self) -> IncidentRepository: ...
    def notifier(self) -> Notifier: ...


class InMemoryFactory:
    def repository(self) -> InMemoryIncidentRepository:
        return InMemoryIncidentRepository()

    def notifier(self) -> MemoryNotifier:
        return MemoryNotifier()


class ProdFactory:
    def __init__(self, db_path: str) -> None:
        self.db_path = db_path

    def repository(self) -> SqliteIncidentRepository:
        return SqliteIncidentRepository(self.db_path)

    def notifier(self) -> MemoryNotifier:
        # Training stand-in: no real production SMTP credentials are shipped.
        return MemoryNotifier()
