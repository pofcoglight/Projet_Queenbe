"""Validated security-domain objects, independent of technical adapters."""

from __future__ import annotations

import ipaddress
import re
from dataclasses import dataclass, field
from datetime import datetime
from enum import IntEnum, StrEnum
from uuid import UUID, uuid4


class DomainError(ValueError):
    """A domain invariant has been violated."""


class Severity(IntEnum):
    LOW = 1
    MEDIUM = 2
    HIGH = 3
    CRITICAL = 4


class IncidentStatus(StrEnum):
    OPEN = "open"
    TRIAGED = "triaged"
    CLOSED = "closed"


_ALLOWED_ACTIONS = frozenset({"login_failed", "login_ok", "port_probe", "logout"})
_USERNAME = re.compile(r"[A-Za-z0-9_.@-]{1,64}\Z", flags=re.ASCII)


@dataclass(frozen=True, slots=True)
class SecurityEvent:
    source_ip: str
    username: str
    action: str
    timestamp: datetime

    def __post_init__(self) -> None:
        try:
            ipaddress.ip_address(self.source_ip)
        except ValueError as exc:
            raise DomainError("Invalid source IP") from exc
        if not isinstance(self.username, str) or _USERNAME.fullmatch(self.username) is None:
            raise DomainError("Invalid username")
        if self.action not in _ALLOWED_ACTIONS:
            raise DomainError("Unknown security action")
        if not isinstance(self.timestamp, datetime) or self.timestamp.utcoffset() is None:
            raise DomainError("Timezone-aware timestamp required")


@dataclass(frozen=True, slots=True)
class Alert:
    rule: str
    source_ip: str
    severity: Severity
    message: str

    def __post_init__(self) -> None:
        if not self.rule:
            raise DomainError("Alert rule required")
        try:
            ipaddress.ip_address(self.source_ip)
        except ValueError as exc:
            raise DomainError("Invalid alert IP") from exc
        if type(self.severity) is int:
            try:
                object.__setattr__(self, "severity", Severity(self.severity))
            except ValueError as exc:
                raise DomainError("Invalid alert severity") from exc
        elif not isinstance(self.severity, Severity):
            raise DomainError("Invalid alert severity")


@dataclass(slots=True)
class Incident:
    alert: Alert
    id: UUID = field(default_factory=uuid4)
    status: IncidentStatus = IncidentStatus.OPEN

    def transition_to(self, new_status: IncidentStatus) -> None:
        allowed = {
            IncidentStatus.OPEN: {IncidentStatus.TRIAGED},
            IncidentStatus.TRIAGED: {IncidentStatus.CLOSED},
            IncidentStatus.CLOSED: set(),
        }
        if new_status not in allowed[self.status]:
            raise DomainError(f"Invalid incident transition: {self.status} -> {new_status}")
        self.status = new_status


@dataclass(frozen=True, slots=True)
class Principal:
    username: str
    roles: frozenset[str]

    def __post_init__(self) -> None:
        if _USERNAME.fullmatch(self.username) is None:
            raise DomainError("Invalid principal")
