"""Detection strategies, composition and an allowlisted rule factory."""

from __future__ import annotations

from collections import Counter
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from typing import Protocol

from queenbee.domain.model import Alert, DomainError, SecurityEvent, Severity


class DetectionRule(Protocol):
    @property
    def name(self) -> str: ...

    def evaluate(self, events: Sequence[SecurityEvent]) -> list[Alert]: ...


def _threshold(value: int) -> None:
    # bool is an int subtype in Python: exact type is critical here.
    if type(value) is not int or value < 1:
        raise DomainError("Threshold must be a positive integer")


@dataclass(frozen=True, slots=True)
class BruteForceRule:
    threshold: int = 5

    def __post_init__(self) -> None:
        _threshold(self.threshold)

    @property
    def name(self) -> str:
        return "brute_force"

    def evaluate(self, events: Sequence[SecurityEvent]) -> list[Alert]:
        failures = Counter(e.source_ip for e in events if e.action == "login_failed")
        return [
            Alert(self.name, ip, Severity.HIGH, f"{count} failed logins from {ip}")
            for ip, count in failures.items()
            if count >= self.threshold
        ]


@dataclass(frozen=True, slots=True)
class PortScanRule:
    threshold: int = 20

    def __post_init__(self) -> None:
        _threshold(self.threshold)

    @property
    def name(self) -> str:
        return "port_scan"

    def evaluate(self, events: Sequence[SecurityEvent]) -> list[Alert]:
        probes = Counter(e.source_ip for e in events if e.action == "port_probe")
        return [
            Alert(self.name, ip, Severity.MEDIUM, f"{count} port probes from {ip}")
            for ip, count in probes.items()
            if count >= self.threshold
        ]


@dataclass(frozen=True, slots=True)
class RuleSet:
    rules: tuple[DetectionRule, ...]

    @property
    def name(self) -> str:
        return "ruleset"

    def evaluate(self, events: Sequence[SecurityEvent]) -> list[Alert]:
        return [alert for rule in self.rules for alert in rule.evaluate(events)]


_REGISTERED_RULES: dict[str, type[BruteForceRule] | type[PortScanRule]] = {
    "brute_force": BruteForceRule,
    "port_scan": PortScanRule,
}


def build_rule(config: Mapping[str, object]) -> DetectionRule:
    """Choose known constructors only; no dynamic imports or getattr."""
    kind = config.get("kind")
    if not isinstance(kind, str) or kind not in _REGISTERED_RULES:
        raise DomainError("Unknown rule")
    threshold = config.get("threshold", 5 if kind == "brute_force" else 20)
    if type(threshold) is not int or threshold < 1:
        raise DomainError("Threshold must be a positive integer")
    return _REGISTERED_RULES[kind](threshold=threshold)
