"""Composition root: dependencies are created once and passed explicitly."""

from __future__ import annotations

from collections.abc import Sequence

from queenbee.adapters.inbound.log_parser import parse_sshd_line
from queenbee.adapters.outbound.notifiers import MemoryNotifier
from queenbee.adapters.outbound.repositories import InMemoryIncidentRepository
from queenbee.application.services import DetectionService
from queenbee.config import Settings
from queenbee.domain.model import DomainError, Incident, SecurityEvent
from queenbee.domain.rules import BruteForceRule


class QueenBee:
    def __init__(self, service: DetectionService) -> None:
        self._service = service
        self.rejected = 0

    def ingest_lines(self, lines: Sequence[str]) -> list[Incident]:
        events: list[SecurityEvent] = []
        for line in lines:
            try:
                events.append(parse_sshd_line(line))
            except DomainError:
                self.rejected += 1
        return self._service.ingest(events)


def build_app(settings: Settings) -> QueenBee:
    """Uses in-memory infrastructure for the training demo, never globals."""
    _ = settings
    return QueenBee(
        DetectionService(BruteForceRule(), InMemoryIncidentRepository(), [MemoryNotifier()])
    )
